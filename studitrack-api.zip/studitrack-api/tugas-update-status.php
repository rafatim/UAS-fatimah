<?php
// Koneksi ke database
$koneksi = mysqli_connect("localhost", "fore6986_studitrack", "studitrack_1234", "fore6986_db_api_studitrack");

// Header JSON
header("Content-Type: application/json");

// Ambil input dari POST
$id_tugas = $_POST['id_tugas'] ?? null;
$status   = $_POST['status'] ?? null;

// Validasi input
if (!$id_tugas || $status === null) {
    echo json_encode([
        "status" => false,
        "message" => "ID tugas dan status wajib dikirim"
    ]);
    exit;
}

// Cek apakah data tugas ada
$cek = mysqli_query($koneksi, "SELECT * FROM tugas WHERE id_tugas = '$id_tugas'");
if (mysqli_num_rows($cek) == 0) {
    echo json_encode([
        "status" => false,
        "message" => "Data tugas tidak ditemukan"
    ]);
    exit;
}

// Update status
$update = mysqli_query($koneksi, "UPDATE tugas SET status = '$status' WHERE id_tugas = '$id_tugas'");

// Respon
if ($update) {
    echo json_encode([
        "status" => true,
        "message" => "Status tugas berhasil diperbarui"
    ]);
} else {
    echo json_encode([
        "status" => false,
        "message" => "Gagal memperbarui status tugas"
    ]);
}
?>
