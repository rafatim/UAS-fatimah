<?php
$koneksi = mysqli_connect("localhost", "fore6986_studitrack", "studitrack_1234", "fore6986_db_api_studitrack");
header("Content-Type: application/json");

// Ambil data input
$id_users     = $_POST['id_users'] ?? null;
$email        = mysqli_real_escape_string($koneksi, $_POST['email'] ?? '');
$nama_lengkap = mysqli_real_escape_string($koneksi, $_POST['nama_lengkap'] ?? '');
$password     = mysqli_real_escape_string($koneksi, $_POST['password'] ?? '');
$hapus_foto   = isset($_POST['hapus_foto']) && $_POST['hapus_foto'] == '1';

// Validasi ID
if (!$id_users) {
    echo json_encode(["status" => false, "message" => "ID pengguna tidak dikirim"]);
    exit;
}

// Cek user lama
$cek_user = mysqli_query($koneksi, "SELECT * FROM users WHERE id_users = '$id_users'");
if (mysqli_num_rows($cek_user) == 0) {
    echo json_encode(["status" => false, "message" => "Pengguna tidak ditemukan"]);
    exit;
}
$old_user = mysqli_fetch_assoc($cek_user);

// Cek duplikat email
$cek_email = mysqli_query($koneksi, "SELECT * FROM users WHERE email = '$email' AND id_users != '$id_users'");
if (mysqli_num_rows($cek_email) > 0) {
    echo json_encode(["status" => false, "message" => "Email sudah digunakan oleh pengguna lain"]);
    exit;
}

// Inisialisasi update foto
$update_foto = "";
$foto_user = $old_user['foto_user'];

// Proses hapus foto
if ($hapus_foto && !empty($foto_user) && file_exists($foto_user)) {
    unlink($foto_user); // hapus file fisik
    $foto_user = "";
    $update_foto = ", foto_user=''";
}

// Jika upload file baru
if (!empty($_FILES['foto_user']['name'])) {
    $target_dir = "uploads/";
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $nama_file = uniqid() . "_" . basename($_FILES['foto_user']['name']);
    $target_file = $target_dir . $nama_file;

    if (move_uploaded_file($_FILES["foto_user"]["tmp_name"], $target_file)) {
        // Hapus foto lama jika ada
        if (!empty($foto_user) && file_exists($foto_user)) {
            unlink($foto_user);
        }
        $foto_user = $target_file;
        $update_foto = ", foto_user='$foto_user'";
    } else {
        echo json_encode(["status" => false, "message" => "Gagal upload foto"]);
        exit;
    }
}

// Update data
$query = mysqli_query($koneksi, "UPDATE users SET 
    email='$email',
    nama_lengkap='$nama_lengkap',
    password='$password'
    $update_foto
    WHERE id_users='$id_users'");

if ($query) {
    echo json_encode([
        "status" => true,
        "message" => "Profil berhasil diperbarui",
        "data" => [
            "id_users"     => $id_users,
            "email"        => $email,
            "nama_lengkap" => $nama_lengkap,
            "password"     => $password,
            "foto_user"    => $foto_user
        ]
    ]);
} else {
    echo json_encode(["status" => false, "message" => "Gagal memperbarui data pengguna"]);
}
?>
