<?php
$koneksi = mysqli_connect("localhost", "fore6986_studitrack", "studitrack_1234", "fore6986_db_api_studitrack");

header("Content-Type: application/json");

// Ambil data dari POST
$id_users    = $_POST['id_users'] ?? null;
$matkul      = $_POST['matkul'] ?? '';
$pengajar    = $_POST['pengajar'] ?? '';
$hari        = $_POST['hari'] ?? '';
$jam_mulai   = $_POST['jam_mulai'] ?? '';
$jam_selesai = $_POST['jam_selesai'] ?? '';
$lokasi      = $_POST['lokasi'] ?? '';
$foto_url    = ""; // default kosong

// Validasi id_users
$cek_user = mysqli_query($koneksi, "SELECT id_users FROM users WHERE id_users = '$id_users'");
if (mysqli_num_rows($cek_user) == 0) {
    echo json_encode(["status" => false, "message" => "ID pengguna tidak ditemukan"]);
    exit;
}

// Proses upload file (jika ada)
$upload_folder = "uploads/";
$base_url = "http://fatimaa.fortunis11.com/studitrack-api/";

if (!is_dir($upload_folder)) {
    mkdir($upload_folder, 0777, true);
}

if (!empty($_FILES['foto_jadwal']['name'])) {
    $ext = pathinfo($_FILES['foto_jadwal']['name'], PATHINFO_EXTENSION);
    $nama_file = uniqid() . "_" . time() . "." . $ext;
    $target_path = $upload_folder . $nama_file;
    $foto_url = $base_url . $target_path;

    if (!move_uploaded_file($_FILES['foto_jadwal']['tmp_name'], $target_path)) {
        echo json_encode(["status" => false, "message" => "Gagal upload file gambar"]);
        exit;
    }
}

// Simpan ke database
$query = mysqli_query($koneksi, "INSERT INTO jadwal (
    id_users, matkul, pengajar, foto_jadwal, hari, jam_mulai, jam_selesai, lokasi
) VALUES (
    '$id_users', '$matkul', '$pengajar', '$foto_url', '$hari', '$jam_mulai', '$jam_selesai', '$lokasi'
)");

if ($query) {
    echo json_encode([
        "status" => true,
        "message" => "Jadwal berhasil ditambahkan",
        "data" => [
            "foto_jadwal" => $foto_url
        ]
    ]);
} else {
    echo json_encode(["status" => false, "message" => "Gagal menyimpan data ke database"]);
}
?>
