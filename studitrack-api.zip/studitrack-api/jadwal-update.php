<?php
$koneksi = mysqli_connect("localhost", "fore6986_studitrack", "studitrack_1234", "fore6986_db_api_studitrack");
header("Content-Type: application/json");

$id_jadwal   = $_POST['id_jadwal'] ?? null;
$matkul      = $_POST['matkul'] ?? '';
$pengajar    = $_POST['pengajar'] ?? '';
$hari        = $_POST['hari'] ?? '';
$jam_mulai   = $_POST['jam_mulai'] ?? '';
$jam_selesai = $_POST['jam_selesai'] ?? '';
$lokasi      = $_POST['lokasi'] ?? '';
$hapus_foto  = $_POST['hapus_foto'] ?? '0'; // 1 untuk hapus foto
$update_foto = "";

// Cek apakah data ditemukan
$cek = mysqli_query($koneksi, "SELECT * FROM jadwal WHERE id_jadwal = '$id_jadwal'");
if (mysqli_num_rows($cek) == 0) {
    echo json_encode(["status" => false, "message" => "Data jadwal tidak ditemukan"]);
    exit;
}
$dataLama = mysqli_fetch_assoc($cek);

// Base URL & folder upload
$base_url = "http://fatimaa.fortunis11.com/studitrack-api/";
$target_dir = "uploads/";

if (!is_dir($target_dir)) {
    mkdir($target_dir, 0777, true);
}

// Fungsi hapus file lama jika ada
function hapusFotoLama($foto_url) {
    $path = str_replace("http://fatimaa.fortunis11.com/studitrack-api/", "", $foto_url);
    if (file_exists($path)) {
        unlink($path);
    }
}

// Jika ingin hapus foto
if ($hapus_foto === '1' && !empty($dataLama['foto_jadwal'])) {
    hapusFotoLama($dataLama['foto_jadwal']);
    $update_foto = ", foto_jadwal=''";
}

// Jika upload foto baru
if (!empty($_FILES['foto_jadwal']['name'])) {
    $nama_file = uniqid() . "_" . basename($_FILES['foto_jadwal']['name']);
    $target_file = $target_dir . $nama_file;
    $foto_url = $base_url . $target_file;

    if (move_uploaded_file($_FILES["foto_jadwal"]["tmp_name"], $target_file)) {
        // Hapus foto lama jika ada
        if (!empty($dataLama['foto_jadwal'])) {
            hapusFotoLama($dataLama['foto_jadwal']);
        }
        $update_foto = ", foto_jadwal='$foto_url'";
    } else {
        echo json_encode(["status" => false, "message" => "Gagal upload file gambar"]);
        exit;
    }
}

// Update data jadwal
$query = mysqli_query($koneksi, "UPDATE jadwal SET 
    matkul='$matkul', 
    pengajar='$pengajar', 
    hari='$hari', 
    jam_mulai='$jam_mulai', 
    jam_selesai='$jam_selesai', 
    lokasi='$lokasi'
    $update_foto
    WHERE id_jadwal='$id_jadwal'");

if ($query) {
    echo json_encode(["status" => true, "message" => "Data jadwal berhasil diperbarui"]);
} else {
    echo json_encode(["status" => false, "message" => "Gagal update data"]);
}
?>
