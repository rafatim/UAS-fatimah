<?php
$koneksi = mysqli_connect("localhost", "fore6986_studitrack", "studitrack_1234", "fore6986_db_api_studitrack");

header("Content-Type: application/json");

// Cek apakah id_jadwal dikirim
if (!isset($_POST['id_jadwal'])) {
    echo json_encode(["status" => false, "message" => "ID jadwal tidak dikirim"]);
    exit;
}

$id_jadwal = $_POST['id_jadwal'];

// Cek apakah data ada
$cek = mysqli_query($koneksi, "SELECT * FROM jadwal WHERE id_jadwal = '$id_jadwal'");
if (mysqli_num_rows($cek) == 0) {
    echo json_encode(["status" => false, "message" => "Data tidak ditemukan"]);
    exit;
}

// Hapus data
$query = mysqli_query($koneksi, "DELETE FROM jadwal WHERE id_jadwal = '$id_jadwal'");

if ($query) {
    echo json_encode(["status" => true, "message" => "Data berhasil dihapus"]);
} else {
    echo json_encode(["status" => false, "message" => "Gagal menghapus data"]);
}
?>
