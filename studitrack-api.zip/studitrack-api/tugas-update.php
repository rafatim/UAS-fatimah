<?php
$koneksi = mysqli_connect("localhost", "fore6986_studitrack", "studitrack_1234", "fore6986_db_api_studitrack");
header("Content-Type: application/json");

// Ambil data dari POST
$id_tugas          = $_POST['id_tugas'] ?? null;
$id_jadwal         = $_POST['id_jadwal'] ?? null;
$judul             = $_POST['judul'] ?? '';
$deskripsi         = $_POST['deskripsi'] ?? '';
$tanggal_daedline  = $_POST['tanggal_daedline'] ?? '';
$status            = $_POST['status'] ?? 0;
$hapusFoto         = isset($_POST['hapus_foto']) && ($_POST['hapus_foto'] === "1" || $_POST['hapus_foto'] === 1);

$base_url   = "http://fatimaa.fortunis11.com/studitrack-api/";
$target_dir = "uploads/";
$update_foto = "";

// 🔍 Validasi ID tugas
if (!$id_tugas) {
    echo json_encode(["status" => false, "message" => "ID tugas tidak dikirim"]);
    exit;
}

// 🔎 Ambil data lama tugas
$cek = mysqli_query($koneksi, "SELECT * FROM tugas WHERE id_tugas = '$id_tugas'");
$dataLama = mysqli_fetch_assoc($cek);
if (!$dataLama) {
    echo json_encode(["status" => false, "message" => "Tugas tidak ditemukan"]);
    exit;
}

// 🧠 Ambil jenis dari tabel jadwal
if ($id_jadwal) {
    $cek_jadwal = mysqli_query($koneksi, "SELECT matkul FROM jadwal WHERE id_jadwal = '$id_jadwal'");
    if (mysqli_num_rows($cek_jadwal) == 0) {
        echo json_encode(["status" => false, "message" => "ID jadwal tidak ditemukan"]);
        exit;
    }
    $jenis = mysqli_fetch_assoc($cek_jadwal)['matkul'];
} else {
    $id_jadwal = $dataLama['id_jadwal']; // tetap gunakan jadwal lama
    $jenis = $dataLama['jenis'];
}

// 🗑️ Hapus foto jika diminta
if ($hapusFoto && !empty($dataLama['foto_tugas'])) {
    $old_path = str_replace($base_url, "", $dataLama['foto_tugas']);
    $old_path = __DIR__ . '/' . $old_path;
    if (file_exists($old_path)) {
        unlink($old_path);
    }
    $update_foto = ", foto_tugas=''";
}

// 📁 Upload foto baru
if (!empty($_FILES['foto_tugas']['name'])) {
    // Hapus foto lama dulu
    if (!empty($dataLama['foto_tugas']) && !filter_var($dataLama['foto_tugas'], FILTER_VALIDATE_URL)) {
        $old_path = str_replace($base_url, "", $dataLama['foto_tugas']);
        $old_path = __DIR__ . '/' . $old_path;
        if (file_exists($old_path)) {
            unlink($old_path);
        }
    }

    // Pastikan folder upload ada
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $nama_file   = uniqid() . "_" . preg_replace("/[^a-zA-Z0-9.\-_]/", "", basename($_FILES['foto_tugas']['name']));
    $target_file = $target_dir . $nama_file;
    $foto_url    = $base_url . $target_file;

    if (move_uploaded_file($_FILES["foto_tugas"]["tmp_name"], $target_file)) {
        $update_foto = ", foto_tugas='$foto_url'";
    } else {
        echo json_encode(["status" => false, "message" => "Gagal upload foto"]);
        exit;
    }
}

// 🌐 Jika URL foto dikirim manual
elseif (!empty($_POST['foto_tugas_url']) && filter_var($_POST['foto_tugas_url'], FILTER_VALIDATE_URL)) {
    $foto_url = $_POST['foto_tugas_url'];
    $update_foto = ", foto_tugas='$foto_url'";
}

// 🔄 Update ke database
$query = mysqli_query($koneksi, "UPDATE tugas SET 
    id_jadwal='$id_jadwal',
    judul='$judul',
    deskripsi='$deskripsi',
    jenis='$jenis',
    tanggal_daedline='$tanggal_daedline',
    status='$status'
    $update_foto
    WHERE id_tugas='$id_tugas'
");

if ($query) {
    echo json_encode(["status" => true, "message" => "Tugas berhasil diperbarui"]);
} else {
    echo json_encode(["status" => false, "message" => "Gagal update data"]);
}
?>
