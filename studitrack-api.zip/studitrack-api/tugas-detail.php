<?php
$koneksi = mysqli_connect("localhost", "fore6986_studitrack", "studitrack_1234", "fore6986_db_api_studitrack");
header("Content-Type: application/json");

// Ambil parameter dari URL
$id_users = $_GET['id_users'] ?? null;
$keyword = $_GET['keyword'] ?? '';
$status = $_GET['status'] ?? '';

if (!$id_users) {
    echo json_encode(["status" => false, "message" => "ID pengguna tidak dikirim"]);
    exit;
}

// Cek apakah user ada
$cek_user = mysqli_query($koneksi, "SELECT id_users FROM users WHERE id_users = '$id_users'");
if (mysqli_num_rows($cek_user) == 0) {
    echo json_encode(["status" => false, "message" => "Pengguna tidak ditemukan"]);
    exit;
}

$base_url = "http://fatimaa.fortunis11.com/studitrack-api/";
$keyword = mysqli_real_escape_string($koneksi, $keyword);
$status = mysqli_real_escape_string($koneksi, $status);

// Query JOIN jadwal untuk ambil matkul
$sql = "
    SELECT 
        tugas.*, 
        jadwal.matkul 
    FROM tugas 
    LEFT JOIN jadwal ON tugas.id_jadwal = jadwal.id_jadwal 
    WHERE tugas.id_users = '$id_users'
";

// Filter tambahan
if (!empty($status)) {
    $sql .= " AND tugas.status = '$status'";
}
if (!empty($keyword)) {
    $sql .= " AND (
        tugas.judul LIKE '%$keyword%' OR 
        tugas.jenis LIKE '%$keyword%' OR 
        tugas.tanggal_daedline LIKE '%$keyword%'
    )";
}

$sql .= " ORDER BY tugas.tanggal_daedline ASC";

$query = mysqli_query($koneksi, $sql);
$data = [];

while ($row = mysqli_fetch_assoc($query)) {
    // Perbaiki URL foto
    if (!empty($row['foto_tugas']) && !filter_var($row['foto_tugas'], FILTER_VALIDATE_URL)) {
        $row['foto_tugas'] = $base_url . $row['foto_tugas'];
    }
    $data[] = $row;
}

// Respon akhir
if (!empty($data)) {
    echo json_encode([
        "status" => true,
        "message" => "Data ditemukan",
        "jumlah" => count($data),
        "data" => $data
    ]);
} else {
    echo json_encode([
        "status" => false,
        "message" => "Tugas tidak ditemukan",
        "data" => []
    ]);
}
?>
