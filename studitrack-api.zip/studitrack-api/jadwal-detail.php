<?php
$koneksi = mysqli_connect("localhost", "fore6986_studitrack", "studitrack_1234", "fore6986_db_api_studitrack");

header("Content-Type: application/json");

$id_users = $_GET['id_users'] ?? null;
$keyword = $_GET['keyword'] ?? '';
$hari = $_GET['hari'] ?? ''; // ← ambil parameter hari dari URL

if (!$id_users) {
    echo json_encode(["status" => false, "message" => "ID pengguna tidak dikirim"]);
    exit;
}

// Cek apakah user ada
$cek_user = mysqli_query($koneksi, "SELECT id_users FROM users WHERE id_users = '$id_users'");
if (mysqli_num_rows($cek_user) == 0) {
    echo json_encode(["status" => false, "message" => "Pengguna tidak ditemukan"]);
    exit;
}

// Escape keyword dan hari
$keyword = mysqli_real_escape_string($koneksi, $keyword);
$hari = mysqli_real_escape_string($koneksi, $hari);

// Build query
$sql = "SELECT * FROM jadwal WHERE id_users = '$id_users'";

// Jika filter hari digunakan
if (!empty($hari)) {
    $sql .= " AND hari = '$hari'";
}

// Jika keyword digunakan
if (!empty($keyword)) {
    $sql .= " AND (
        matkul LIKE '%$keyword%' OR 
        pengajar LIKE '%$keyword%' OR 
        lokasi LIKE '%$keyword%' OR 
        hari LIKE '%$keyword%'  -- ← tambahkan pencarian berdasarkan hari
    )";
}

$sql .= " ORDER BY FIELD(hari, 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu')";

$query = mysqli_query($koneksi, $sql);

// Ambil hasil dan kirim response
$data = [];
while ($row = mysqli_fetch_assoc($query)) {
    $data[] = $row;
}

if (!empty($data)) {
    echo json_encode([
        "status" => true,
        "message" => "Data ditemukan",
        "jumlah" => count($data),
        "data" => $data
    ]);
} else {
    echo json_encode([
        "status" => false,
        "message" => "Data tidak ditemukan"
    ]);
}
?>
