<?php
$koneksi = mysqli_connect("localhost", "fore6986_studitrack", "studitrack_1234", "fore6986_db_api_studitrack");
header("Content-Type: application/json");

// Ambil parameter dari URL
$id_users = $_GET['id_users'] ?? null;

if (!$id_users) {
    echo json_encode(["status" => false, "message" => "ID pengguna tidak dikirim"]);
    exit;
}

// Cek apakah user ada
$cek_user = mysqli_query($koneksi, "SELECT id_users FROM users WHERE id_users = '$id_users'");
if (mysqli_num_rows($cek_user) == 0) {
    echo json_encode(["status" => false, "message" => "Pengguna tidak ditemukan"]);
    exit;
}

$base_url = "http://fatimaa.fortunis11.com/studitrack-api/";
$folder_uploads = "uploads/";

// Query untuk ambil data tugas dengan join ke jadwal
$sql = "
    SELECT 
        tugas.*, 
        jadwal.matkul 
    FROM tugas 
    LEFT JOIN jadwal ON tugas.id_jadwal = jadwal.id_jadwal 
    WHERE tugas.id_users = '$id_users' 
    ORDER BY tugas.tanggal_daedline ASC
";

$query = mysqli_query($koneksi, $sql);
$data = [];

while ($row = mysqli_fetch_assoc($query)) {
    // Perbaiki URL foto jika bukan URL
    if (!empty($row['foto_tugas']) && !filter_var($row['foto_tugas'], FILTER_VALIDATE_URL)) {
        $row['foto_tugas'] = $base_url . $row['foto_tugas'];
    }

    // Tambahkan fallback jika matkul kosong (misal data jadwal sudah dihapus)
    if (!isset($row['matkul']) || $row['matkul'] == null) {
        $row['matkul'] = $row['jenis']; // fallback dari kolom jenis
    }

    $data[] = $row;
}

// Output response
if (!empty($data)) {
    echo json_encode([
        "status" => true,
        "message" => "Data tugas ditemukan",
        "jumlah" => count($data),
        "data" => $data
    ]);
} else {
    echo json_encode([
        "status" => false,
        "message" => "Belum ada data tugas",
        "data" => []
    ]);
}
?>
