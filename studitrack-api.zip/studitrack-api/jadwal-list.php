<?php
$koneksi = mysqli_connect("localhost", "fore6986_studitrack", "studitrack_1234", "fore6986_db_api_studitrack");

header("Content-Type: application/json");

// Validasi jika id_users tidak dikirim
if (!isset($_GET['id_users']) || empty($_GET['id_users'])) {
    echo json_encode(["status" => false, "message" => "ID pengguna tidak dikirim"]);
    exit;
}

$id_users = $_GET['id_users'];

// Cek apakah user ada
$cek_user = mysqli_query($koneksi, "SELECT id_users FROM users WHERE id_users = '$id_users'");
if (mysqli_num_rows($cek_user) == 0) {
    echo json_encode(["status" => false, "message" => "Pengguna tidak ditemukan"]);
    exit;
}

// Ambil semua data jadwal user
$query = mysqli_query($koneksi, "
    SELECT * FROM jadwal 
    WHERE id_users = '$id_users' 
    ORDER BY FIELD(hari, 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu')
");

$data = [];
while ($row = mysqli_fetch_assoc($query)) {
    $data[] = $row;
}

echo json_encode([
    "status" => true,
    "message" => "Data jadwal ditemukan",
    "jumlah" => count($data),
    "data" => $data
]);
?>
