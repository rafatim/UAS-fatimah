<?php
$koneksi = mysqli_connect("localhost", "fore6986_studitrack", "studitrack_1234", "fore6986_db_api_studitrack");

header("Content-Type: application/json");

// Ambil data dari POST
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

// Validasi input kosong
if (empty($email) || empty($password)) {
    echo json_encode([
        "status" => false,
        "message" => "Email dan password wajib diisi"
    ]);
    exit;
}

// Query pengguna
$query = mysqli_query($koneksi, "SELECT * FROM users WHERE email = '$email'");

// Cek apakah user ditemukan
if (mysqli_num_rows($query) == 0) {
    echo json_encode([
        "status" => false,
        "message" => "Email tidak ditemukan"
    ]);
    exit;
}

// Ambil data user
$data = mysqli_fetch_assoc($query);

// Bandingkan password (jika pakai hash, ubah jadi password_verify)
if ($password === $data['password']) {
    echo json_encode([
        "status" => true,
        "message" => "Login berhasil",
        "data" => $data
    ]);
} else {
    echo json_encode([
        "status" => false,
        "message" => "Password salah"
    ]);
}
?>
