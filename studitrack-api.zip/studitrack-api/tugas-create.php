<?php
$koneksi = mysqli_connect("localhost", "fore6986_studitrack", "studitrack_1234", "fore6986_db_api_studitrack");
header("Content-Type: application/json");

// Ambil data dari POST
$id_users         = $_POST['id_users'] ?? null;
$id_jadwal        = $_POST['id_jadwal'] ?? null;
$judul            = $_POST['judul'] ?? '';
$deskripsi        = $_POST['deskripsi'] ?? '';
$tanggal_daedline = $_POST['tanggal_daedline'] ?? '';
$foto_url         = ''; // default kosong
$status           = 0; // default belum selesai

// 🔍 Validasi ID pengguna
if (!$id_users || !$id_jadwal || empty($judul) || empty($deskripsi) || empty($tanggal_daedline)) {
    echo json_encode(["status" => false, "message" => "Data tidak lengkap"]);
    exit;
}

// 🔍 Cek pengguna
$cek_user = mysqli_query($koneksi, "SELECT id_users FROM users WHERE id_users = '$id_users'");
if (mysqli_num_rows($cek_user) == 0) {
    echo json_encode(["status" => false, "message" => "ID pengguna tidak ditemukan"]);
    exit;
}

// 🔍 Cek jadwal & ambil matkul sebagai jenis
$cek_jadwal = mysqli_query($koneksi, "SELECT matkul FROM jadwal WHERE id_jadwal = '$id_jadwal'");
if (mysqli_num_rows($cek_jadwal) == 0) {
    echo json_encode(["status" => false, "message" => "ID jadwal tidak ditemukan"]);
    exit;
}
$jadwal_data = mysqli_fetch_assoc($cek_jadwal);
$jenis = $jadwal_data['matkul'];

// 📁 Konfigurasi upload
$base_url   = "http://fatimaa.fortunis11.com/studitrack-api/";
$target_dir = "uploads/";

if (!is_dir($target_dir)) {
    mkdir($target_dir, 0777, true);
}

// 📷 1. Upload file jika ada
if (!empty($_FILES['foto_tugas']['name'])) {
    $original_name = basename($_FILES['foto_tugas']['name']);
    $safe_name     = preg_replace('/[^A-Za-z0-9_.-]/', '_', $original_name);
    $nama_file     = uniqid() . "_" . $safe_name;
    $target_file   = $target_dir . $nama_file;

    if (!move_uploaded_file($_FILES["foto_tugas"]["tmp_name"], $target_file)) {
        echo json_encode(["status" => false, "message" => "Gagal upload file gambar"]);
        exit;
    }

    $foto_url = $base_url . $target_file;
}
// 🌐 2. Jika dikirim URL manual
elseif (!empty($_POST['foto_url'])) {
    $foto_url = $_POST['foto_url'];
}

// 💾 Simpan ke tabel tugas
$query = mysqli_query($koneksi, "INSERT INTO tugas (
    id_users, id_jadwal, judul, foto_tugas, deskripsi, jenis, tanggal_daedline, status
) VALUES (
    '$id_users', '$id_jadwal', '$judul', '$foto_url', '$deskripsi', '$jenis', '$tanggal_daedline', '$status'
)");

if ($query) {
    echo json_encode(["status" => true, "message" => "Tugas berhasil ditambahkan"]);
} else {
    echo json_encode(["status" => false, "message" => "Gagal menyimpan data ke database"]);
}
?>
