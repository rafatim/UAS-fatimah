<?php
$koneksi = mysqli_connect("localhost", "fore6986_studitrack", "studitrack_1234", "fore6986_db_api_studitrack");

header("Content-Type: application/json");

// Validasi ID tugas
$id_tugas = $_POST['id_tugas'] ?? null;
if (!$id_tugas) {
    echo json_encode(["status" => false, "message" => "ID tugas tidak dikirim"]);
    exit;
}

// Cek apakah data tugas tersedia
$cek = mysqli_query($koneksi, "SELECT * FROM tugas WHERE id_tugas = '$id_tugas'");
$data = mysqli_fetch_assoc($cek);

if (!$data) {
    echo json_encode(["status" => false, "message" => "Tugas tidak ditemukan"]);
    exit;
}

// Hapus file gambar jika ada dan berupa file lokal
if (!empty($data['foto_tugas']) && !filter_var($data['foto_tugas'], FILTER_VALIDATE_URL)) {
    $path = str_replace("http://fatimaa.fortunis11.com/studitrack-api/", "", $data['foto_tugas']);
    if (file_exists($path)) {
        unlink($path); // hapus file dari server
    }
}

// Eksekusi DELETE
$query = mysqli_query($koneksi, "DELETE FROM tugas WHERE id_tugas = '$id_tugas'");

if ($query) {
    echo json_encode(["status" => true, "message" => "Tugas berhasil dihapus"]);
} else {
    echo json_encode(["status" => false, "message" => "Gagal menghapus tugas"]);
}
?>
