// Import library untuk parsing JSON, UI, HTTP, dan penyimpanan lokal
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// Deklarasi halaman HomePage
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String? namaLengkap; // Menyimpan nama lengkap user
  String? idUsers; // Menyimpan ID user
  int _selectedIndex = 0; // Indeks menu bawah yang aktif (0 = Home)

  List tugas = []; // List tugas belum selesai
  List tugasSelesai = []; // List tugas yang sudah selesai
  List jadwal = []; // List jadwal untuk hari ini

  final Color primaryColor = const Color(0xFF608CAD); // Warna utama (biru abu)
  final Color navBgColor = const Color(0xFF052944); // Warna background navbar

  final GlobalKey<AnimatedListState> _listKey = GlobalKey<AnimatedListState>(); // Key untuk AnimatedList

  @override
  void initState() {
    super.initState();
    loadUserData(); // Panggil saat widget dibuat
  }

  // Memuat data user dari SharedPreferences
  Future<void> loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    final userString = prefs.getString('user');
    if (userString != null) {
      final user = json.decode(userString);
      setState(() {
        namaLengkap = user['nama_lengkap'];
        idUsers = user['id_users'].toString();
      });
      fetchData(); // Fetch data setelah user berhasil dimuat
    }
  }

  // Mengambil data tugas dan jadwal dari API
  Future<void> fetchData() async {
    if (idUsers == null) return;
    final now = DateTime.now();
    final hari = _convertHari(now.weekday); // Konversi ke nama hari

    final tugasUrl = Uri.parse(
        'http://fatimaa.fortunis11.com/studitrack-api/tugas-detail.php?id_users=${Uri.encodeComponent(idUsers!)}');
    final jadwalUrl = Uri.parse(
        'http://fatimaa.fortunis11.com/studitrack-api/jadwal-detail.php?id_users=${Uri.encodeComponent(idUsers!)}&hari=${Uri.encodeComponent(hari)}');

    try {
      final tugasRes = await http.get(tugasUrl);
      final jadwalRes = await http.get(jadwalUrl);

      final tugasData = json.decode(tugasRes.body);
      final jadwalData = json.decode(jadwalRes.body);

      List allTugas = tugasData['status'] == true && tugasData['data'] != null
          ? List.from(tugasData['data'])
          : [];

      setState(() {
        tugas = allTugas.where((t) => t['status'] == '0').toList(); // Filter tugas belum selesai
        tugasSelesai = allTugas.where((t) => t['status'] == '1').toList(); // Tugas selesai
        jadwal = jadwalData['status'] == true
            ? List.from(jadwalData['data']) // Ambil list jadwal hari ini
            : [];
      });
    } catch (e) {
      debugPrint('❌ Error fetchData: $e'); // Tangani error API
    }
  }

  // Konversi integer weekday ke nama hari
  String _convertHari(int weekday) {
    const hariList = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
    return hariList[weekday - 1];
  }

  // Ubah status tugas ke selesai dengan animasi
  void ubahStatusTugasAnimasi(int index, String idTugas) async {
    final response = await http.post(
      Uri.parse("http://fatimaa.fortunis11.com/studitrack-api/tugas-update-status.php"),
      body: {'id_tugas': idTugas, 'status': '1'},
    );
    final data = json.decode(response.body);
    if (data['status'] == true) {
      final removedItem = tugas.removeAt(index); // Hapus dari list
      _listKey.currentState?.removeItem(
        index,
            (context, animation) => SizeTransition(
          sizeFactor: animation,
          child: Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              title: Text(removedItem['judul'] ?? '-'),
            ),
          ),
        ),
        duration: const Duration(milliseconds: 400),
      );
      await Future.delayed(const Duration(milliseconds: 450)); // Tunggu animasi
      fetchData(); // Reload data
    }
  }

  // Navigasi ke halaman lain dari menu bawah
  void _onNavTapped(int index) {
    if (index == _selectedIndex) return;
    switch (index) {
      case 0:
        Navigator.pushNamedAndRemoveUntil(context, '/home', (route) => false);
        break;
      case 1:
        Navigator.pushNamedAndRemoveUntil(context, '/jadwal', (route) => false);
        break;
      case 2:
        Navigator.pushNamedAndRemoveUntil(context, '/tugas', (route) => false);
        break;
      case 3:
        Navigator.pushNamedAndRemoveUntil(context, '/tentang', (route) => false);
        break;
    }
  }

  // Build UI halaman Home
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // Latar belakang putih
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.white,
        elevation: 0,
        toolbarHeight: 80,
        title: Row(
          children: [
            Image.asset('assets/logo-studitrack.png', height: 120), // Logo aplikasi
            const Spacer(),
            if (namaLengkap != null)
              GestureDetector(
                onTap: () => Navigator.pushNamed(context, '/profile'), // Arahkan ke halaman profil
                child: Row(
                  children: [
                    Text(
                      namaLengkap!,
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          color: primaryColor),
                    ),
                    const SizedBox(width: 6),
                    const Icon(Icons.person, color: Color(0xFF052944)), // Ikon user
                  ],
                ),
              ),
          ],
        ),
      ),
      body: RefreshIndicator(
        onRefresh: fetchData, // Swipe untuk refresh data
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          children: [
            Text("Statistik Tugas",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: primaryColor)),
            const SizedBox(height: 10),
            Row(
              children: [
                _buildStatCard("Belum Selesai", tugas.length, Colors.red), // Jumlah tugas belum selesai
                const SizedBox(width: 10),
                _buildStatCard("Selesai", tugasSelesai.length, Colors.green), // Jumlah tugas selesai
              ],
            ),
            const SizedBox(height: 24),
            Text("Tugas Belum Selesai",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: primaryColor)),
            const SizedBox(height: 10),
            if (tugas.isEmpty)
              const Text("Tidak ada tugas belum selesai.") // Jika kosong
            else
              AnimatedList(
                key: _listKey,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                initialItemCount: tugas.length,
                itemBuilder: (context, index, animation) {
                  final t = tugas[index];
                  return SizeTransition(
                    sizeFactor: animation,
                    child: Card(
                      elevation: 2,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      margin: const EdgeInsets.only(bottom: 12),
                      child: Padding(
                        padding: const EdgeInsets.all(10),
                        child: Column(
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                t['foto_tugas'] != null && t['foto_tugas'] != ''
                                    ? ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Image.network(
                                    t['foto_tugas'],
                                    width: 80,
                                    height: 80,
                                    fit: BoxFit.cover,
                                  ),
                                )
                                    : Container(
                                  width: 80,
                                  height: 80,
                                  decoration: BoxDecoration(
                                    color: navBgColor,
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Icon(Icons.person, color: Colors.white), // Fallback ikon
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(t['judul'] ?? '-', style: const TextStyle(fontWeight: FontWeight.bold)),
                                      Text("Matkul: ${t['nama_matkul'] ?? '-'}"),
                                      Text("Deadline: ${t['tanggal_daedline'] ?? '-'}"),
                                      Text("Deskripsi: ${t['deskripsi'] ?? '-'}"),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Align(
                              alignment: Alignment.centerRight,
                              child: TextButton(
                                onPressed: () => ubahStatusTugasAnimasi(index, t['id_tugas']), // Tombol selesai
                                child: const Text("Tandai Selesai"),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            const SizedBox(height: 24),
            Text("Jadwal Hari Ini",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: primaryColor)),
            const SizedBox(height: 10),
            if (jadwal.isEmpty)
              const Text("Tidak ada jadwal hari ini.") // Jika tidak ada jadwal
            else
              ...jadwal.map((j) => Card(
                elevation: 2,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                margin: const EdgeInsets.only(bottom: 12),
                child: ListTile(
                  leading: j['foto_jadwal'] != null && j['foto_jadwal'] != ''
                      ? ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.network(j['foto_jadwal'],
                        height: 60, width: 60, fit: BoxFit.cover),
                  )
                      : Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      color: Color(0xFF052944),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(Icons.person, color: Colors.white), // Fallback ikon jadwal
                  ),
                  title: Text(j['matkul'] ?? '-', style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(j['pengajar'] ?? ''),
                      const SizedBox(height: 2),
                      Text('${j['hari']} • ${j['jam_mulai']} - ${j['jam_selesai']}'),
                      const SizedBox(height: 2),
                      Text(j['lokasi'] ?? ''),
                    ],
                  ),
                ),
              )),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: navBgColor,
          borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(24), topRight: Radius.circular(24)),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildNavItem(Icons.home, 'Beranda', 0, _selectedIndex == 0),
            _buildNavItem(Icons.schedule, 'Jadwal', 1, _selectedIndex == 1),
            _buildNavItem(Icons.task, 'Tugas', 2, _selectedIndex == 2),
            _buildNavItem(Icons.info_outline, 'Tentang', 3, _selectedIndex == 3),
          ],
        ),
      ),
    );
  }

  // Widget kartu statistik
  Widget _buildStatCard(String title, int count, Color color) => Expanded(
    child: Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Text(count.toString(),
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: color)),
          const SizedBox(height: 4),
          Text(title, style: TextStyle(color: color)),
        ],
      ),
    ),
  );

  // Widget item navigasi bawah
  Widget _buildNavItem(IconData icon, String label, int index, bool selected) => GestureDetector(
    onTap: () => _onNavTapped(index),
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          decoration: selected
              ? const BoxDecoration(shape: BoxShape.circle, color: Colors.white)
              : null,
          padding: const EdgeInsets.all(8),
          child: Icon(icon, color: selected ? primaryColor : Colors.white, size: 24),
        ),
        const SizedBox(height: 4),
        Text(label,
            style: TextStyle(
                color: selected ? primaryColor : Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w500)),
      ],
    ),
  );
}
