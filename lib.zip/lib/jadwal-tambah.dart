// Import package bawaan dan eksternal
import 'dart:convert'; // Untuk konversi JSON
import 'dart:io'; // Untuk operasi file seperti File gambar
import 'package:flutter/material.dart'; // Package utama untuk membuat UI Flutter
import 'package:image_picker/image_picker.dart'; // Package untuk mengambil gambar dari galeri atau kamera
import 'package:http/http.dart' as http; // Untuk melakukan HTTP request
import 'package:shared_preferences/shared_preferences.dart'; // Untuk menyimpan dan membaca data lokal pengguna
import 'package:intl/intl.dart'; // Untuk format waktu

// Widget halaman Tambah Jadwal
class TambahJadwalPage extends StatefulWidget {
  const TambahJadwalPage({super.key});

  @override
  State<TambahJadwalPage> createState() => _TambahJadwalPageState();
}

// State dari halaman Tambah Jadwal
class _TambahJadwalPageState extends State<TambahJadwalPage> {
  final _formKey = GlobalKey<FormState>(); // Key untuk validasi form
  final TextEditingController matkulController = TextEditingController(); // Controller untuk input mata kuliah
  final TextEditingController pengajarController = TextEditingController(); // Controller untuk input pengajar
  final TextEditingController jamMulaiController = TextEditingController(); // Controller untuk input jam mulai
  final TextEditingController jamSelesaiController = TextEditingController(); // Controller untuk input jam selesai
  final TextEditingController lokasiController = TextEditingController(); // Controller untuk input lokasi

  File? foto; // File untuk menyimpan foto yang dipilih
  String? idUsers; // ID pengguna yang login
  String? selectedHari; // Hari yang dipilih dari dropdown
  bool isLoading = false; // Status loading saat simpan data

  final Color primaryColor = const Color(0xFF608CAD); // Warna utama teks
  final Color navBgColor = const Color(0xFF052944); // Warna background tombol simpan

  // Daftar nama hari untuk dropdown
  final List<String> hariList = [
    'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'
  ];

  @override
  void initState() {
    super.initState();
    loadUser(); // Memuat data user dari SharedPreferences saat init
  }

  @override
  void dispose() {
    // Dispose controller ketika widget dihancurkan
    matkulController.dispose();
    pengajarController.dispose();
    jamMulaiController.dispose();
    jamSelesaiController.dispose();
    lokasiController.dispose();
    super.dispose();
  }

  // Fungsi untuk memuat user dari SharedPreferences
  Future<void> loadUser() async {
    final prefs = await SharedPreferences.getInstance();
    final userString = prefs.getString('user');
    if (userString != null) {
      final userData = json.decode(userString);
      setState(() {
        idUsers = userData['id_users']; // Simpan id_users ke variabel
      });
    }
  }

  // Fungsi untuk memilih jam dari time picker
  Future<void> pickTime(TextEditingController controller) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      final now = DateTime.now();
      final dt = DateTime(now.year, now.month, now.day, picked.hour, picked.minute);
      final formatted = DateFormat('HH:mm').format(dt); // Format jam ke HH:mm
      controller.text = formatted; // Simpan ke controller
    }
  }

  // Fungsi untuk menyimpan data jadwal ke server
  Future<void> simpanJadwal() async {
    if (!_formKey.currentState!.validate()) return; // Validasi form
    if (idUsers == null) {
      // Jika id_users belum tersedia, tampilkan snackbar
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("User tidak ditemukan")),
      );
      return;
    }

    setState(() => isLoading = true); // Tampilkan loading

    final uri = Uri.parse("http://fatimaa.fortunis11.com/studitrack-api/jadwal-create.php");
    final request = http.MultipartRequest('POST', uri)
      ..fields['id_users'] = idUsers!
      ..fields['matkul'] = matkulController.text
      ..fields['pengajar'] = pengajarController.text
      ..fields['hari'] = selectedHari!
      ..fields['jam_mulai'] = jamMulaiController.text
      ..fields['jam_selesai'] = jamSelesaiController.text
      ..fields['lokasi'] = lokasiController.text;

    // Jika ada foto yang dipilih, tambahkan ke request
    if (foto != null) {
      request.files.add(await http.MultipartFile.fromPath('foto_jadwal', foto!.path));
    }

    final response = await request.send();
    final responseBody = await response.stream.bytesToString();
    final result = json.decode(responseBody); // Decode hasil response

    setState(() => isLoading = false); // Sembunyikan loading

    if (result['status'] == true) {
      if (mounted) {
        Navigator.pop(context, true); // Kembali ke halaman sebelumnya
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result['message'] ?? 'Gagal menambahkan jadwal')),
      );
    }
  }

  // Fungsi untuk konfirmasi ketika menekan tombol back
  Future<bool> _onBackPressed() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Konfirmasi"),
        content: const Text("Yakin batal menambah jadwal?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text("Tidak")),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text("Ya")),
        ],
      ),
    );
    return confirm ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onBackPressed,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          toolbarHeight: 80,
          automaticallyImplyLeading: false,
          title: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back, color: Color(0xFF052944)),
                onPressed: () async {
                  if (await _onBackPressed()) Navigator.pop(context);
                },
              ),
              Image.asset('assets/logo-studitrack.png', height: 120), // Logo aplikasi
              const Spacer(),
            ],
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  const Center(
                    child: Text(
                      'Jadwal',
                      style: TextStyle(
                        fontSize: 24,
                        color: Color(0xFF608CAD),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Input Mata Kuliah
                  TextFormField(
                    controller: matkulController,
                    decoration: const InputDecoration(
                      labelText: "Mata Kuliah",
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) =>
                    value == null || value.isEmpty ? 'Mata kuliah wajib diisi' : null,
                  ),
                  const SizedBox(height: 16),

                  // Input Pengajar
                  TextFormField(
                    controller: pengajarController,
                    decoration: const InputDecoration(
                      labelText: "Pengajar",
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) =>
                    value == null || value.isEmpty ? 'Pengajar wajib diisi' : null,
                  ),
                  const SizedBox(height: 16),

                  // Dropdown Hari
                  DropdownButtonFormField<String>(
                    value: selectedHari,
                    items: hariList
                        .map((hari) => DropdownMenuItem(value: hari, child: Text(hari)))
                        .toList(),
                    onChanged: (value) => setState(() => selectedHari = value),
                    decoration: const InputDecoration(
                      labelText: 'Hari',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) => value == null ? 'Hari wajib dipilih' : null,
                  ),
                  const SizedBox(height: 16),

                  // Input Jam Mulai (dengan time picker)
                  TextFormField(
                    controller: jamMulaiController,
                    readOnly: true,
                    onTap: () => pickTime(jamMulaiController),
                    decoration: const InputDecoration(
                      labelText: "Jam Mulai",
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) =>
                    value == null || value.isEmpty ? 'Jam mulai wajib diisi' : null,
                  ),
                  const SizedBox(height: 16),

                  // Input Jam Selesai (dengan time picker)
                  TextFormField(
                    controller: jamSelesaiController,
                    readOnly: true,
                    onTap: () => pickTime(jamSelesaiController),
                    decoration: const InputDecoration(
                      labelText: "Jam Selesai",
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) =>
                    value == null || value.isEmpty ? 'Jam selesai wajib diisi' : null,
                  ),
                  const SizedBox(height: 16),

                  // Input Lokasi
                  TextFormField(
                    controller: lokasiController,
                    decoration: const InputDecoration(
                      labelText: "Lokasi",
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) =>
                    value == null || value.isEmpty ? 'Lokasi wajib diisi' : null,
                  ),
                  const SizedBox(height: 16),

                  // Input Foto
                  GestureDetector(
                    onTap: () async {
                      final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
                      if (picked != null) {
                        setState(() => foto = File(picked.path));
                      }
                    },
                    child: InputDecorator(
                      decoration: const InputDecoration(
                        labelText: 'Foto Pengajar (Opsional)',
                        border: OutlineInputBorder(),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.image, color: Colors.grey),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              foto != null ? foto!.path.split('/').last : 'Pilih gambar',
                              style: TextStyle(
                                color: foto != null ? Colors.black87 : Colors.grey,
                              ),
                            ),
                          ),
                          const Icon(Icons.upload_file, color: Colors.grey),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Tombol Simpan
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: isLoading ? null : simpanJadwal,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: navBgColor,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      child: isLoading
                          ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                          : const Text(
                        "Simpan",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
