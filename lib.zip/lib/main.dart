// Import package bawaan Flutter untuk membuat UI
import 'package:flutter/material.dart';

// Import halaman-halaman lokal yang digunakan dalam navigasi
import 'profil-login.dart';
import 'register.dart';
import 'beranda.dart';
import 'profil.dart';
import 'profil-update.dart';
import 'jadwal.dart';
import 'jadwal-tambah.dart';
import 'jadwal-edit.dart';
import 'tugas.dart';
import 'tugas-tambah.dart';
import 'tugas-edit.dart';
import 'about.dart';

// Membuat global observer untuk memantau perubahan rute halaman (berguna untuk navigasi manual dan tracking)
final RouteObserver<PageRoute> routeObserver = RouteObserver<PageRoute>();

// Fungsi utama sebagai titik awal aplikasi
void main() {
  runApp(const StudiTrackApp()); // Menjalankan aplikasi dengan widget utama StudiTrackApp
}

// Kelas utama aplikasi yang menggunakan StatelessWidget karena tidak menyimpan state
class StudiTrackApp extends StatelessWidget {
  const StudiTrackApp({super.key}); // Konstruktor const

  @override
  Widget build(BuildContext context) {
    // MaterialApp adalah root widget untuk aplikasi berbasis Material Design
    return MaterialApp(
      title: 'StudiTrack', // Judul aplikasi
      debugShowCheckedModeBanner: false, // Menyembunyikan label debug di pojok kanan atas
      theme: ThemeData(
        primarySwatch: Colors.indigo, // Warna tema utama aplikasi
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(), // Tema default untuk semua input (TextField) dengan border kotak
        ),
      ),
      navigatorObservers: [routeObserver], // Mengaktifkan route observer
      initialRoute: '/login', // Rute awal saat aplikasi dibuka
      onGenerateRoute: (settings) {
        WidgetBuilder builder; // Builder halaman berdasarkan nama rute

        // Memeriksa nama rute yang diminta dan menetapkan widget yang sesuai
        switch (settings.name) {
          case '/login':
            builder = (context) => const LoginPage(); // Halaman login
            break;
          case '/register':
            builder = (context) => const RegisterPage(); // Halaman registrasi
            break;
          case '/home':
            builder = (context) => const HomePage(); // Halaman beranda
            break;
          case '/profile':
            builder = (context) => const ProfilePage(); // Halaman profil pengguna
            break;
          case '/edit-profile':
            builder = (context) => const EditProfilePage(); // Halaman edit profil
            break;
          case '/jadwal':
            builder = (context) => const JadwalPage(); // Halaman daftar jadwal
            break;
          case '/jadwal-tambah':
            builder = (context) => const TambahJadwalPage(); // Halaman tambah jadwal
            break;
          case '/tugas':
            builder = (context) => const TugasPage(); // Halaman daftar tugas
            break;
          case '/tugas-tambah':
            builder = (context) => const TugasTambahPage(); // Halaman tambah tugas
            break;
          case '/tentang':
            builder = (context) => const TentangPage(); // Halaman tentang aplikasi
            break;
          case '/jadwal-edit':
          // Mendapatkan argumen berupa data jadwal yang ingin diedit dari navigator
            final Map<String, dynamic> jadwal = settings.arguments as Map<String, dynamic>;
            builder = (context) => JadwalEditPage(jadwal: jadwal); // Halaman edit jadwal dengan data
            break;
          case '/tugas-edit':
          // Mendapatkan argumen berupa data tugas yang ingin diedit dari navigator
            final Map<String, dynamic> tugas = settings.arguments as Map<String, dynamic>;
            builder = (context) => TugasEditPage(tugas: tugas); // Halaman edit tugas dengan data
            break;
          default:
            return null; // Jika rute tidak ditemukan, tidak melakukan navigasi
        }

        // Mengembalikan halaman dengan efek transisi fade (memudar)
        return PageRouteBuilder(
          settings: settings, // Menyertakan data pengaturan rute
          pageBuilder: (context, animation, secondaryAnimation) => builder(context), // Halaman yang ingin ditampilkan
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            // Efek transisi fade saat pindah halaman
            return FadeTransition(
              opacity: animation, // Gunakan animasi untuk mengatur transparansi
              child: child, // Widget halaman
            );
          },
          transitionDuration: const Duration(milliseconds: 250), // Durasi transisi 250ms
        );
      },
    );
  }
}
