import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class TugasEditPage extends StatefulWidget {
  final Map tugas;
  const TugasEditPage({super.key, required this.tugas});

  @override
  State<TugasEditPage> createState() => _TugasEditPageState();
}

class _TugasEditPageState extends State<TugasEditPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController judulController = TextEditingController();
  final TextEditingController deskripsiController = TextEditingController();
  final TextEditingController tanggalController = TextEditingController();

  File? _image;
  bool hapusFoto = false;
  bool isLoading = false;
  String? selectedJenis;
  List<Map<String, dynamic>> jadwalList = [];

  @override
  void initState() {
    super.initState();
    final data = widget.tugas;
    judulController.text = data['judul'] ?? '';
    deskripsiController.text = data['deskripsi'] ?? '';
    tanggalController.text = data['tanggal_daedline'] ?? '';
    selectedJenis = data['id_jadwal']; // id_jadwal sebagai value dropdown
    fetchJadwal();
  }

  Future<void> fetchJadwal() async {
    final prefs = await SharedPreferences.getInstance();
    final idUsers = json.decode(prefs.getString('user')!)['id_users'];
    final response = await http.get(Uri.parse(
        'http://fatimaa.fortunis11.com/studitrack-api/jadwal-list.php?id_users=$idUsers'));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      if (data['status']) {
        setState(() {
          jadwalList = List<Map<String, dynamic>>.from(data['data']);
        });
      }
    }
  }

  Future<void> pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() {
        _image = File(picked.path);
        hapusFoto = false;
      });
    }
  }

  Future<void> updateTugas() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => isLoading = true);

    final uri =
    Uri.parse("http://fatimaa.fortunis11.com/studitrack-api/tugas-update.php");
    final request = http.MultipartRequest('POST', uri)
      ..fields['id_tugas'] = widget.tugas['id_tugas']
      ..fields['judul'] = judulController.text
      ..fields['deskripsi'] = deskripsiController.text
      ..fields['tanggal_daedline'] = tanggalController.text
      ..fields['id_jadwal'] = selectedJenis ?? ''
      ..fields['status'] = widget.tugas['status'].toString()
      ..fields['hapus_foto'] = hapusFoto ? '1' : '0';

    if (_image != null) {
      request.files
          .add(await http.MultipartFile.fromPath('foto_tugas', _image!.path));
    } else if (hapusFoto) {
      request.fields['foto_tugas_url'] = '';
    }

    final response = await request.send();
    final res = await response.stream.bytesToString();
    final data = json.decode(res);

    setState(() => isLoading = false);

    if (data['status']) {
      if (mounted) {
        Navigator.pop(context, true);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Tugas berhasil diperbarui')),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(data['message'] ?? 'Gagal update tugas')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final fotoUrl = widget.tugas['foto_tugas'];
    const iconColor = Color(0xFF052944);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        toolbarHeight: 80,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: iconColor),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Image.asset('assets/logo-studitrack.png', height: 120),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              const Text(
                "Edit Tugas",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF608CAD),
                ),
              ),
              const SizedBox(height: 20),

              Stack(
                alignment: Alignment.bottomRight,
                children: [
                  CircleAvatar(
                    radius: 60,
                    backgroundColor: Colors.grey[300],
                    backgroundImage: _image != null
                        ? FileImage(_image!)
                        : (fotoUrl != null &&
                        fotoUrl != "" &&
                        !hapusFoto
                        ? NetworkImage(fotoUrl)
                        : null) as ImageProvider?,
                    child: (_image == null &&
                        (fotoUrl == null || fotoUrl == "" || hapusFoto))
                        ? const Icon(Icons.image, size: 60, color: Colors.white)
                        : null,
                  ),
                  Positioned(
                    bottom: 0,
                    right: 4,
                    child: GestureDetector(
                      onTap: pickImage,
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: const BoxDecoration(
                          color: iconColor,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.edit,
                            color: Colors.white, size: 20),
                      ),
                    ),
                  ),
                ],
              ),

              if (fotoUrl != null &&
                  fotoUrl != "" &&
                  _image == null &&
                  !hapusFoto)
                TextButton.icon(
                  onPressed: () => setState(() => hapusFoto = true),
                  icon: const Icon(Icons.delete_forever, color: Colors.red),
                  label: const Text("Hapus Foto",
                      style: TextStyle(color: Colors.red)),
                ),

              const SizedBox(height: 30),

              TextFormField(
                controller: judulController,
                decoration: const InputDecoration(
                  labelText: 'Judul',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                value == null || value.isEmpty ? 'Judul wajib diisi' : null,
              ),
              const SizedBox(height: 16),

              TextFormField(
                controller: deskripsiController,
                decoration: const InputDecoration(
                  labelText: 'Deskripsi',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value == null || value.isEmpty
                    ? 'Deskripsi wajib diisi'
                    : null,
              ),
              const SizedBox(height: 16),

              TextFormField(
                controller: tanggalController,
                readOnly: true,
                decoration: const InputDecoration(
                  labelText: 'Tanggal Deadline',
                  border: OutlineInputBorder(),
                ),
                onTap: () async {
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: DateTime.tryParse(tanggalController.text) ??
                        DateTime.now(),
                    firstDate: DateTime(2023),
                    lastDate: DateTime(2100),
                  );
                  if (picked != null) {
                    setState(() {
                      tanggalController.text =
                          picked.toIso8601String().split('T').first;
                    });
                  }
                },
                validator: (value) => value == null || value.isEmpty
                    ? 'Tanggal wajib dipilih'
                    : null,
              ),
              const SizedBox(height: 16),

              DropdownButtonFormField<String>(
                value: selectedJenis,
                items: jadwalList.map((item) {
                  return DropdownMenuItem<String>(
                    value: item['id_jadwal'],
                    child: Text(item['matkul']),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() => selectedJenis = value);
                },
                decoration: const InputDecoration(
                  labelText: 'Jenis / Mata Kuliah',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                value == null || value.isEmpty ? 'Pilih mata kuliah' : null,
              ),
              const SizedBox(height: 24),

              isLoading
                  ? const CircularProgressIndicator()
                  : SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: updateTugas,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: iconColor,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text("Simpan Perubahan",
                      style: TextStyle(color: Colors.white)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
