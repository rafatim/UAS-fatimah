// Import package yang diperlukan untuk membuat halaman edit jadwal
import 'dart:convert'; // Untuk decoding response dari API
import 'dart:io'; // Untuk manipulasi file (image upload)
import 'package:flutter/material.dart'; // UI framework utama Flutter
import 'package:image_picker/image_picker.dart'; // Untuk memilih gambar dari gallery
import 'package:http/http.dart' as http; // Untuk melakukan request ke API
import 'package:intl/intl.dart'; // Untuk format jam (misalnya HH:mm)

// Mendefinisikan halaman edit jadwal sebagai widget stateful karena data di dalamnya bisa berubah, seperti input form dan gambar
class JadwalEditPage extends StatefulWidget {
  final Map<String, dynamic> jadwal; // Data jadwal yang akan diedit

  const JadwalEditPage({super.key, required this.jadwal});

  @override
  State<JadwalEditPage> createState() => _JadwalEditPageState();
}

class _JadwalEditPageState extends State<JadwalEditPage> {
  final _formKey = GlobalKey<FormState>();
  final List<String> hariList = [
    'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'
  ];

  late TextEditingController matkulController;
  late TextEditingController pengajarController;
  late TextEditingController jamMulaiController;
  late TextEditingController jamSelesaiController;
  late TextEditingController lokasiController;

  String? selectedHari;
  File? foto;
  bool hapusFoto = false;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    final data = widget.jadwal;
    matkulController = TextEditingController(text: data['matkul']);
    pengajarController = TextEditingController(text: data['pengajar']);
    jamMulaiController = TextEditingController(text: data['jam_mulai']);
    jamSelesaiController = TextEditingController(text: data['jam_selesai']);
    lokasiController = TextEditingController(text: data['lokasi']);
    selectedHari = data['hari'];
  }

  Future<void> pilihJam(TextEditingController controller) async {
    final picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      final format = DateFormat('HH:mm');
      final now = DateTime.now();
      final dt = DateTime(now.year, now.month, now.day, picked.hour, picked.minute);
      controller.text = format.format(dt);
    }
  }

  Future<void> updateJadwal() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => isLoading = true);

    final uri = Uri.parse("http://fatimaa.fortunis11.com/studitrack-api/jadwal-update.php");
    final request = http.MultipartRequest('POST', uri)
      ..fields['id_jadwal'] = widget.jadwal['id_jadwal']
      ..fields['matkul'] = matkulController.text
      ..fields['pengajar'] = pengajarController.text
      ..fields['hari'] = selectedHari!
      ..fields['jam_mulai'] = jamMulaiController.text
      ..fields['jam_selesai'] = jamSelesaiController.text
      ..fields['lokasi'] = lokasiController.text
      ..fields['hapus_foto'] = hapusFoto ? '1' : '0';

    if (foto != null) {
      request.files.add(await http.MultipartFile.fromPath('foto_jadwal', foto!.path));
    }

    final response = await request.send();
    final resBody = await response.stream.bytesToString();
    final result = json.decode(resBody);

    setState(() => isLoading = false);

    if (result['status']) {
      if (mounted) Navigator.pop(context, true);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Jadwal berhasil diperbarui")),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result['message'] ?? "Gagal memperbarui jadwal")),
      );
    }
  }

  Future<bool> onBackPressed() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Batalkan Edit?"),
        content: const Text("Yakin tidak jadi mengubah jadwal ini?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text("Lanjutkan Edit")),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text("Ya, Batal")),
        ],
      ),
    );
    return confirm ?? false;
  }

  @override
  Widget build(BuildContext context) {
    const Color iconColor = Color(0xFF052944);
    const Color textColor = Color(0xFF608CAD);
    final fotoNetwork = widget.jadwal['foto_jadwal'];

    ImageProvider? displayedImage;
    if (foto != null) {
      displayedImage = FileImage(foto!);
    } else if (!hapusFoto && fotoNetwork != null && fotoNetwork != "") {
      displayedImage = NetworkImage(fotoNetwork);
    }

    return WillPopScope(
      onWillPop: onBackPressed,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          automaticallyImplyLeading: false,
          toolbarHeight: 80,
          title: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back, color: iconColor),
                onPressed: () async {
                  if (await onBackPressed()) Navigator.pop(context);
                },
              ),
              Image.asset('assets/logo-studitrack.png', height: 120),
              const Spacer(),
            ],
          ),
        ),
        body: isLoading
            ? const Center(child: CircularProgressIndicator())
            : SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                const Center(
                  child: Text("Edit Jadwal",
                      style: TextStyle(color: textColor, fontSize: 24, fontWeight: FontWeight.bold)),
                ),
                const SizedBox(height: 20),

                // Foto dengan Icon Edit
                Stack(
                  alignment: Alignment.bottomRight,
                  children: [
                    CircleAvatar(
                      radius: 50,
                      backgroundColor: Colors.grey[300],
                      backgroundImage: displayedImage,
                      child: displayedImage == null
                          ? const Icon(Icons.person, size: 50, color: Colors.white)
                          : null,
                    ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: GestureDetector(
                        onTap: () async {
                          final picked =
                          await ImagePicker().pickImage(source: ImageSource.gallery);
                          if (picked != null) {
                            setState(() {
                              foto = File(picked.path);
                              hapusFoto = false;
                            });
                          }
                        },
                        child: Container(
                          padding: const EdgeInsets.all(6),
                          decoration: const BoxDecoration(
                            color: iconColor,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.edit, color: Colors.white, size: 18),
                        ),
                      ),
                    ),
                  ],
                ),

                // Tombol hapus foto
                if (!hapusFoto && fotoNetwork != null && fotoNetwork != "" && foto == null)
                  TextButton.icon(
                    onPressed: () {
                      setState(() {
                        hapusFoto = true;
                        foto = null;
                      });
                    },
                    icon: const Icon(Icons.delete_forever, color: Colors.red),
                    label: const Text("Hapus Foto", style: TextStyle(color: Colors.red)),
                  ),

                const SizedBox(height: 16),

                TextFormField(
                  controller: matkulController,
                  decoration: const InputDecoration(
                    labelText: "Mata Kuliah",
                    border: OutlineInputBorder(),
                  ),
                  validator: (val) => val!.isEmpty ? "Wajib diisi" : null,
                ),
                const SizedBox(height: 12),

                TextFormField(
                  controller: pengajarController,
                  decoration: const InputDecoration(
                    labelText: "Pengajar",
                    border: OutlineInputBorder(),
                  ),
                  validator: (val) => val!.isEmpty ? "Wajib diisi" : null,
                ),
                const SizedBox(height: 12),

                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(
                    labelText: "Hari",
                    border: OutlineInputBorder(),
                  ),
                  value: selectedHari,
                  items: hariList.map((h) => DropdownMenuItem(value: h, child: Text(h))).toList(),
                  onChanged: (val) => setState(() => selectedHari = val),
                  validator: (val) => val == null ? "Pilih hari" : null,
                ),
                const SizedBox(height: 12),

                TextFormField(
                  controller: jamMulaiController,
                  readOnly: true,
                  decoration: const InputDecoration(
                    labelText: "Jam Mulai",
                    border: OutlineInputBorder(),
                  ),
                  onTap: () => pilihJam(jamMulaiController),
                  validator: (val) => val!.isEmpty ? "Pilih jam mulai" : null,
                ),
                const SizedBox(height: 12),

                TextFormField(
                  controller: jamSelesaiController,
                  readOnly: true,
                  decoration: const InputDecoration(
                    labelText: "Jam Selesai",
                    border: OutlineInputBorder(),
                  ),
                  onTap: () => pilihJam(jamSelesaiController),
                  validator: (val) => val!.isEmpty ? "Pilih jam selesai" : null,
                ),
                const SizedBox(height: 12),

                TextFormField(
                  controller: lokasiController,
                  decoration: const InputDecoration(
                    labelText: "Lokasi",
                    border: OutlineInputBorder(),
                  ),
                  validator: (val) => val!.isEmpty ? "Wajib diisi" : null,
                ),
                const SizedBox(height: 24),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: updateJadwal,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: iconColor,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: const Text("Simpan Perubahan", style: TextStyle(color: Colors.white)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}