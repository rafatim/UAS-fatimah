import 'dart:convert'; // Untuk decoding JSON user dari SharedPreferences
import 'package:flutter/material.dart'; // UI Flutter
import 'package:shared_preferences/shared_preferences.dart'; // Menyimpan/mengambil data login user

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  String? namaLengkap;
  String? email;
  String? fotoUser;

  final Color primaryColor = const Color(0xFF608CAD); // Warna utama
  final Color navBgColor = const Color(0xFF052944); // Warna background navbar
  int _selectedIndex = 4; // Indeks tab yang aktif, 4 = Profil

  @override
  void initState() {
    super.initState();
    loadUserData();// Ambil data user dari SharedPreferences
  }

  Future<void> loadUserData() async {
    final prefs = await SharedPreferences.getInstance(); // Ambil instance
    final userString = prefs.getString('user'); // Ambil data user (string JSON)
    if (userString != null) {
      final user = json.decode(userString); // Decode JSON
      setState(() {
        namaLengkap = user['nama_lengkap'];
        email = user['email'];
        fotoUser = user['foto_user']; // Simpan ke state
      });
    }
  }

  //Fungsi ini mengembalikan URL lengkap ke foto user, apakah berupa URL absolut atau path relatif.
  String? get fullFotoUrl {
    if (fotoUser != null && fotoUser!.isNotEmpty) {
      return fotoUser!.startsWith('http')
          ? fotoUser
          : 'http://fatimaa.fortunis11.com/studitrack-api/$fotoUser';
    }
    return null;
  }

  Future<void> logout() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Konfirmasi"),
        content: const Text("Yakin Anda ingin logout?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false), // Batal
            child: const Text("Batal"),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true), // Konfirmasi logout
            child: const Text("Logout"),
          ),
        ],
      ),
    );

    if (confirm == true) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('user'); // Hapus data user
      Navigator.pushReplacementNamed(context, '/login'); // Redirect ke login
    }
  }

  void navigateToEditProfile() async {
    await Navigator.pushNamed(context, '/edit-profile'); // Buka halaman edit profil
    loadUserData(); // Setelah kembali, ambil ulang data user
  }

  void _onNavTapped(int index) {
    if (index == _selectedIndex) return; // Jika sedang aktif, tidak lakukan apapun
    setState(() => _selectedIndex = index); // Update indeks

    switch (index) {
      case 0:
        Navigator.pushNamedAndRemoveUntil(context, '/home', (route) => false);
        break;
      case 1:
        Navigator.pushNamedAndRemoveUntil(context, '/jadwal', (route) => false);
        break;
      case 2:
        Navigator.pushNamedAndRemoveUntil(context, '/tugas', (route) => false);
        break;
      case 3:
        Navigator.pushNamedAndRemoveUntil(context, '/tentang', (route) => false);
        break;
      default:
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    const textColor = Color(0xFF608CAD);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        automaticallyImplyLeading: false,
        toolbarHeight: 80,
        title: Row(
          children: [
            Image.asset('assets/logo-studitrack.png', height: 120),
            const Spacer(),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 10),
            Center(
              child: CircleAvatar(
                radius: 57,
                backgroundColor: Colors.grey[300],
                backgroundImage: (fullFotoUrl != null) ? NetworkImage(fullFotoUrl!) : null,
                child: (fullFotoUrl == null)
                    ? const Icon(Icons.person, size: 57, color: Colors.white)
                    : null,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              namaLengkap ?? '',
              style: const TextStyle(
                fontSize: 25,
                fontWeight: FontWeight.bold,
                color: textColor,
              ),
            ),
            const SizedBox(height: 1),
            Text(
              email ?? '',
              style: const TextStyle(
                fontSize: 17,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 30),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: navigateToEditProfile,
                icon: const Icon(Icons.edit),
                label: const Text('Edit Profil'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueGrey,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  textStyle: const TextStyle(fontSize: 16),
                ),
              ),
            ),
            const SizedBox(height: 12),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: logout,
                icon: const Icon(Icons.logout),
                label: const Text('Logout'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  textStyle: const TextStyle(fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),

      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: navBgColor.withOpacity(0.95),
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildBottomItem(Icons.home, 'Beranda', 0),
            _buildBottomItem(Icons.schedule, 'Jadwal', 1),
            _buildBottomItem(Icons.task, 'Tugas', 2),
            _buildBottomItem(Icons.info_outline, 'Tentang', 3),
            // _buildBottomItem(Icons.person, 'Profil', 4),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomItem(IconData icon, String label, int index) {
    return GestureDetector(
      onTap: () => _onNavTapped(index), // Pindah tab saat ditekan
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: _selectedIndex == index
                ? const BoxDecoration(shape: BoxShape.circle, color: Colors.white)
                : null,
            child: Icon(icon, color: _selectedIndex == index ? primaryColor : Colors.white),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: _selectedIndex == index ? primaryColor : Colors.white,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}
