import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class TentangPage extends StatefulWidget {
  const TentangPage({super.key});

  @override
  State<TentangPage> createState() => _TentangPageState();
}

class _TentangPageState extends State<TentangPage> {
  String? namaLengkap;

  final Color primaryColor = const Color(0xFF608CAD); // Warna utama aplikasi
  final Color navBgColor = const Color(0xFF052944);   // Warna nav bottom
  int _selectedIndex = 3; // Posisi 'Tentang'

  @override
  void initState() {
    super.initState();
    loadUser(); // Ambil nama user saat page dibuka
  }

  Future<void> loadUser() async {
    final prefs = await SharedPreferences.getInstance();
    final user = prefs.getString('user');
    if (user != null) {
      final data = json.decode(user);
      setState(() {
        namaLengkap = data['nama_lengkap'];
      });
    }
  }

  void _onNavTapped(int index) {
    if (index == _selectedIndex) return;
    setState(() => _selectedIndex = index);
    switch (index) {
      case 0:
        Navigator.pushReplacementNamed(context, '/home');
        break;
      case 1:
        Navigator.pushReplacementNamed(context, '/jadwal');
        break;
      case 2:
        Navigator.pushReplacementNamed(context, '/tugas');
        break;
      case 3:
        Navigator.pushReplacementNamed(context, '/');
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.white,
        elevation: 0,
        toolbarHeight: 80,
        title: Row(
          children: [
            Image.asset('assets/logo-studitrack.png', height: 120),
            const Spacer(),
            if (namaLengkap != null)
              GestureDetector(
                onTap: () => Navigator.pushNamed(context, '/profile'),
                child: Row(
                  children: [
                    Text(
                      namaLengkap!,
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          color: primaryColor),
                    ),
                    const SizedBox(width: 6),
                    const Icon(Icons.person, color: Color(0xFF052944)),
                  ],
                ),
              ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Tentang StudiTrack",
                style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: primaryColor)),
            const SizedBox(height: 12),
            const Text(
              "StudiTrack adalah aplikasi manajemen studi yang dirancang untuk membantu mahasiswa mengatur jadwal kuliah dan menyelesaikan tugas tepat waktu. Dengan fitur-fitur yang mudah digunakan, pengguna dapat dengan cepat menambahkan, mengedit, dan memantau kegiatan akademik mereka.",
              style: TextStyle(fontSize: 16, height: 1.6),
            ),
            const SizedBox(height: 20),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.network(
                'https://i.pinimg.com/736x/34/db/e6/34dbe65f7bb3540cd44a005b81b90108.jpg',
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 30),
            Text("Motivasi Belajar",
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: primaryColor)),
            const SizedBox(height: 8),
            const Text(
              "Setiap langkah kecil yang kamu ambil hari ini akan membawamu lebih dekat ke impianmu.\n\n"
                  "Jangan takut dengan tugas yang menumpuk, karena setiap tugas yang kamu selesaikan adalah satu langkah menuju sukses.\n\n"
                  "Ingat, belajar bukan hanya tentang nilai, tapi tentang proses dan perjuangan. Teruslah berjuang dan jangan menyerah!",
              style: TextStyle(fontSize: 16, height: 1.6),
            ),
            const SizedBox(height: 40),
            Center(
              child: Text("Versi Aplikasi: 1.0.0",
                  style: TextStyle(color: Colors.grey[600])),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: navBgColor.withOpacity(0.95),
          borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(20), topRight: Radius.circular(20)),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildNavItem(Icons.home, 'Beranda', 0, _selectedIndex == 0),
            _buildNavItem(Icons.schedule, 'Jadwal', 1, _selectedIndex == 1),
            _buildNavItem(Icons.task, 'Tugas', 2, _selectedIndex == 2),
            _buildNavItem(Icons.info_outline, 'Tentang', 3, _selectedIndex == 3),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem(
      IconData icon, String label, int index, bool selected) {
    return GestureDetector(
      onTap: () => _onNavTapped(index),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: selected
                ? const BoxDecoration(
                shape: BoxShape.circle, color: Colors.white)
                : null,
            child: Icon(icon, color: selected ? primaryColor : Colors.white),
          ),
          const SizedBox(height: 4),
          Text(label,
              style: TextStyle(
                  color: selected ? primaryColor : Colors.white,
                  fontSize: 12)),
        ],
      ),
    );
  }
}
