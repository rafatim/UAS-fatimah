import 'dart:convert'; // untuk decoding data JSON dari response API
import 'package:flutter/material.dart'; // package utama untuk membangun UI Flutter
import 'package:http/http.dart' as http; // untuk melakukan HTTP request
import 'package:shared_preferences/shared_preferences.dart'; // untuk menyimpan dan mengambil data lokal pengguna

// Halaman utama untuk menampilkan daftar tugas
class TugasPage extends StatefulWidget {
  const TugasPage({super.key});

  @override
  State<TugasPage> createState() => _TugasPageState();
}

class _TugasPageState extends State<TugasPage> {
  List<dynamic> tugasList = []; // menyimpan daftar tugas
  String? idUsers, namaLengkap; // menyimpan id user dan nama lengkap dari shared preferences
  bool isLoading = false; // indikator loading
  String searchKeyword = ""; // keyword pencarian
  String selectedFilter = 'Semua'; // filter status tugas
  final searchController = TextEditingController(); // controller input pencarian

  final Color primaryColor = const Color(0xFF608CAD); // warna utama teks/icon
  final Color iconColor = const Color(0xFF052944); // warna ikon
  final Color navBgColor = const Color(0xFF052944); // warna background bottom navigation
  int _selectedIndex = 2; // index aktif pada bottom navigation

  List<bool> expandedList = []; // list untuk menyimpan status expand/collapse deskripsi

  @override
  void initState() {
    super.initState();
    loadUserData(); // memuat data user dari local storage saat halaman dimuat
    searchController.addListener(_onSearchChanged); // menambahkan listener saat keyword berubah
  }

  @override
  void dispose() {
    searchController.removeListener(_onSearchChanged); // hapus listener saat dispose
    searchController.dispose(); // dispose controller
    super.dispose();
  }

  void _onSearchChanged() {
    setState(() => searchKeyword = searchController.text.trim()); // update keyword pencarian
    fetchTugas(); // fetch ulang data berdasarkan keyword
  }

  Future<void> loadUserData() async {
    final prefs = await SharedPreferences.getInstance(); // ambil shared preferences
    final user = prefs.getString('user'); // ambil data user dari shared preferences
    if (user != null) {
      final data = json.decode(user); // decode JSON
      idUsers = data['id_users'];
      namaLengkap = data['nama_lengkap'];
      setState(() {});
      fetchTugas(); // setelah dapat user, fetch data tugas
    }
  }

  Future<void> fetchTugas() async {
    if (idUsers == null) return;
    setState(() => isLoading = true); // tampilkan indikator loading

    // URL API tergantung apakah ada keyword pencarian
    final url = searchKeyword.isEmpty
        ? 'http://fatimaa.fortunis11.com/studitrack-api/tugas-list.php?id_users=$idUsers'
        : 'http://fatimaa.fortunis11.com/studitrack-api/tugas-detail.php?id_users=$idUsers&keyword=${Uri.encodeComponent(searchKeyword)}';

    try {
      final response = await http.get(Uri.parse(url)); // kirim HTTP GET
      final data = json.decode(response.body); // decode response JSON
      if (data['status']) {
        List allTugas = data['data']; // ambil semua data tugas dari API
        List filtered = allTugas;

        // filter berdasarkan status jika dipilih
        if (selectedFilter == 'Selesai') {
          filtered = allTugas.where((t) => t['status'] == '1').toList();
        } else if (selectedFilter == 'Belum Selesai') {
          filtered = allTugas.where((t) => t['status'] == '0').toList();
        }

        // urutkan berdasarkan tanggal deadline
        filtered.sort((a, b) => a['tanggal_daedline'].compareTo(b['tanggal_daedline']));

        setState(() {
          tugasList = filtered; // set hasil ke list tugas
          expandedList = List<bool>.filled(filtered.length, false); // siapkan list expand
        });
      } else {
        setState(() {
          tugasList = []; // kosongkan jika gagal
          expandedList = [];
        });
      }
    } catch (e) {
      debugPrint("❌ Exception: $e");
      setState(() {
        tugasList = []; // jika error, kosongkan
        expandedList = [];
      });
    }

    setState(() => isLoading = false); // sembunyikan loading
  }

  // Fungsi hapus tugas dengan konfirmasi
  Future<void> hapusTugas(String idTugas) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Konfirmasi"),
        content: const Text("Yakin ingin menghapus tugas ini?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text("Batal")),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text("Hapus")),
        ],
      ),
    );

    if (confirm == true) {
      final response = await http.post(
        Uri.parse('http://fatimaa.fortunis11.com/studitrack-api/tugas-delete.php'),
        body: {'id_tugas': idTugas},
      );
      final result = json.decode(response.body);
      if (result['status']) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Tugas berhasil dihapus'), duration: Duration(milliseconds: 800)),
        );
        await fetchTugas(); // refresh data
      }
    }
  }

  // Fungsi ubah status tugas selesai/belum
  Future<void> ubahStatusTugas(String idTugas, String newStatus) async {
    final response = await http.post(
      Uri.parse('http://fatimaa.fortunis11.com/studitrack-api/tugas-update-status.php'),
      body: {'id_tugas': idTugas, 'status': newStatus},
    );
    final result = json.decode(response.body);
    if (result['status']) {
      await fetchTugas(); // refresh data
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Status tugas berhasil diubah'), duration: Duration(milliseconds: 800)),
        );
      }
    }
  }

  // Fungsi navigasi bottom menu
  void _onNavTapped(int index) {
    if (index == _selectedIndex) return;
    setState(() => _selectedIndex = index);

    switch (index) {
      case 0:
        Navigator.pushNamedAndRemoveUntil(context, '/home', (route) => false);
        break;
      case 1:
        Navigator.pushNamedAndRemoveUntil(context, '/jadwal', (route) => false);
        break;
      case 2:
        break; // tugas aktif
      case 3:
        Navigator.pushNamedAndRemoveUntil(context, '/tentang', (route) => false);
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    // tampilan utama halaman tugas
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.white,
        elevation: 0,
        toolbarHeight: 80,
        title: Row(
          children: [
            Image.asset('assets/logo-studitrack.png', height: 120), // logo
            const Spacer(),
            if (namaLengkap != null)
              GestureDetector(
                onTap: () => Navigator.pushNamed(context, '/profile'), // klik ke profil
                child: Row(
                  children: [
                    Text(namaLengkap!, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: primaryColor)),
                    const SizedBox(width: 6),
                    const Icon(Icons.person, color: Color(0xFF052944)),
                  ],
                ),
              ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // input pencarian
            TextField(
              controller: searchController,
              decoration: InputDecoration(
                hintText: "Cari Tugas...",
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: () {
                    searchController.clear();
                    setState(() => searchKeyword = "");
                    fetchTugas();
                  },
                ),
              ),
            ),
            const SizedBox(height: 8),
            // filter dropdown
            Align(
              alignment: Alignment.centerRight,
              child: DropdownButton<String>(
                value: selectedFilter,
                items: const [
                  DropdownMenuItem(value: 'Semua', child: Text("Semua")),
                  DropdownMenuItem(value: 'Belum Selesai', child: Text("Belum Selesai")),
                  DropdownMenuItem(value: 'Selesai', child: Text("Selesai")),
                ],
                onChanged: (value) {
                  if (value != null) {
                    setState(() => selectedFilter = value);
                    fetchTugas();
                  }
                },
              ),
            ),
            const SizedBox(height: 8),
            // tampilan daftar tugas
            Expanded(
              child: isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : tugasList.isEmpty
                  ? const Center(child: Text("Belum ada data tugas"))
                  : ListView.builder(
                itemCount: tugasList.length,
                itemBuilder: (context, index) {
                  final item = tugasList[index];
                  final isSelesai = item['status'] == '1';
                  final isExpanded = expandedList[index];

                  return AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    transitionBuilder: (child, animation) {
                      return SlideTransition(
                        position: Tween<Offset>(
                          begin: const Offset(0, 0.1),
                          end: Offset.zero,
                        ).animate(animation),
                        child: FadeTransition(opacity: animation, child: child),
                      );
                    },
                    child: Container(
                      key: ValueKey(item['id_tugas']),
                      margin: const EdgeInsets.only(bottom: 16),
                      decoration: BoxDecoration(
                        color: isSelesai ? Colors.green[50] : Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.08),
                            blurRadius: 6,
                            offset: const Offset(0, 3),
                          ),
                        ],
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // gambar tugas
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: item['foto_tugas'] != null && item['foto_tugas'] != ''
                                ? ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Image.network(
                                item['foto_tugas'],
                                width: 80,
                                height: 80,
                                fit: BoxFit.cover,
                              ),
                            )
                                : Container(
                              width: 80,
                              height: 80,
                              decoration: BoxDecoration(
                                color: Colors.grey.shade300,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Icon(Icons.image, color: Colors.white),
                            ),
                          ),
                          // isi tugas
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(top: 12, right: 12, bottom: 12),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text("Matkul: ${item['matkul'] ?? '-'}"),
                                  Text("Deadline: ${item['tanggal_daedline'] ?? '-'}"),
                                  Text(
                                    "Deskripsi: ${isExpanded ? item['deskripsi'] : (item['deskripsi'].toString().length > 60 ? item['deskripsi'].toString().substring(0, 60) + '...' : item['deskripsi'])}",
                                  ),
                                  if (item['deskripsi'].toString().length > 60)
                                    TextButton(
                                      onPressed: () {
                                        setState(() => expandedList[index] = !expandedList[index]);
                                      },
                                      child: Text(isExpanded ? 'Sembunyikan' : 'Lihat Selengkapnya'),
                                    ),
                                  Row(
                                    children: [
                                      Text("Belum Selesai", style: TextStyle(color: Colors.grey.shade600)),
                                      Switch(
                                        value: isSelesai,
                                        activeColor: Colors.green,
                                        onChanged: (val) => ubahStatusTugas(item['id_tugas'], val ? '1' : '0'),
                                      ),
                                      Text("Selesai", style: TextStyle(color: Colors.green.shade700)),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                          // tombol edit dan hapus
                          Column(
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit, color: Color(0xFF052944)),
                                onPressed: () async {
                                  final result = await Navigator.pushNamed(
                                    context,
                                    '/tugas-edit',
                                    arguments: item,
                                  );
                                  if (result == true) {
                                    await fetchTugas();
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('Tugas berhasil diperbarui'), duration: Duration(milliseconds: 800)),
                                    );
                                  }
                                },
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete, color: Colors.red),
                                onPressed: () => hapusTugas(item['id_tugas']),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      // tombol tambah tugas
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.pushNamed(context, '/tugas-tambah');
          if (result == true) {
            await fetchTugas();
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Tugas berhasil ditambahkan'), duration: Duration(milliseconds: 800)),
            );
          }
        },
        backgroundColor: iconColor,
        child: const Icon(Icons.add, color: Colors.white),
      ),
      // bottom navigation bar
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: navBgColor.withOpacity(0.95),
          borderRadius: const BorderRadius.only(topLeft: Radius.circular(20), topRight: Radius.circular(20)),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildBottomItem(Icons.home, 'Beranda', 0),
            _buildBottomItem(Icons.schedule, 'Jadwal', 1),
            _buildBottomItem(Icons.task, 'Tugas', 2),
            _buildBottomItem(Icons.info_outline, 'Tentang', 3),
          ],
        ),
      ),
    );
  }

  // builder item navigasi bawah
  Widget _buildBottomItem(IconData icon, String label, int index) {
    return GestureDetector(
      onTap: () => _onNavTapped(index),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: _selectedIndex == index ? const BoxDecoration(shape: BoxShape.circle, color: Colors.white) : null,
            child: Icon(icon, color: _selectedIndex == index ? primaryColor : Colors.white),
          ),
          const SizedBox(height: 4),
          Text(label, style: TextStyle(color: _selectedIndex == index ? primaryColor : Colors.white, fontSize: 12)),
        ],
      ),
    );
  }
}
