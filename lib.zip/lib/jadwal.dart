// Import library penting
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// Halaman JadwalPage sebagai StatefulWidget
class JadwalPage extends StatefulWidget {
  const JadwalPage({super.key});

  @override
  State<JadwalPage> createState() => _JadwalPageState();
}

// State dari JadwalPage
class _JadwalPageState extends State<JadwalPage>
    with SingleTickerProviderStateMixin {
  List<dynamic> jadwalList = []; // Menyimpan list jadwal
  String? idUsers; // Menyimpan ID user
  String? namaLengkap; // Menyimpan nama user
  bool isLoading = false; // Status loading
  String searchKeyword = ""; // Kata kunci pencarian
  final TextEditingController searchController = TextEditingController(); // Controller input pencarian

  // Urutan hari untuk penyortiran
  final List<String> hariUrut = [
    'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'
  ];

  final Color primaryColor = const Color(0xFF608CAD); // Warna utama
  final Color navBgColor = const Color(0xFF052944); // Warna latar nav
  int _selectedIndex = 1; // Indeks nav aktif

  bool _isFirstBuild = true; // Cek apakah pertama kali dibuka

  // Kontrol animasi fade
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
    loadUserData(); // Memuat data user saat inisialisasi
  }

  @override
  void dispose() {
    _controller.dispose(); // Hapus controller saat dispose
    super.dispose();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_isFirstBuild && ModalRoute.of(context)?.isCurrent == true) {
      fetchJadwal(resetKeyword: true); // Refresh jika kembali ke halaman
    }
    _isFirstBuild = false;
  }

  // Memuat data user dari SharedPreferences
  Future<void> loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    final user = prefs.getString('user');
    if (user != null) {
      final data = json.decode(user);
      setState(() {
        idUsers = data['id_users'];
        namaLengkap = data['nama_lengkap'];
      });
      fetchJadwal(); // Ambil data jadwal
    }
  }

  // Mengambil data jadwal dari API
  Future<void> fetchJadwal({bool resetKeyword = false}) async {
    if (idUsers == null) return;
    setState(() => isLoading = true); // Tampilkan loading

    if (resetKeyword) {
      searchKeyword = "";
      searchController.clear(); // Reset pencarian
    }

    final url = searchKeyword.isEmpty
        ? 'http://fatimaa.fortunis11.com/studitrack-api/jadwal-list.php?id_users=$idUsers'
        : 'http://fatimaa.fortunis11.com/studitrack-api/jadwal-detail.php?id_users=$idUsers&keyword=$searchKeyword';

    final response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      if (data['status']) {
        final allJadwal = data['data'] as List;
        allJadwal.sort((a, b) =>
            hariUrut.indexOf(a['hari']).compareTo(hariUrut.indexOf(b['hari'])));
        setState(() {
          jadwalList = allJadwal;
        });
        _controller.forward(from: 0); // Jalankan animasi
      } else {
        setState(() {
          jadwalList = []; // Kosongkan jika tidak ada
        });
      }
    }
    setState(() => isLoading = false); // Sembunyikan loading
  }

  // Fungsi untuk menghapus jadwal
  Future<void> hapusJadwal(String idJadwal) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Konfirmasi"),
        content: const Text("Yakin ingin menghapus data ini?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text("Batal")),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text("Hapus")),
        ],
      ),
    );

    if (confirm == true) {
      final response = await http.post(
        Uri.parse('http://fatimaa.fortunis11.com/studitrack-api/jadwal-delete.php'),
        body: {'id_jadwal': idJadwal},
      );
      final result = json.decode(response.body);
      if (result['status']) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Jadwal berhasil dihapus')),
        );
        await fetchJadwal(resetKeyword: true); // Refresh list
      }
    }
  }

  // Fungsi navigasi menu bawah
  void _onNavTapped(int index) {
    if (index == _selectedIndex) return;

    switch (index) {
      case 0:
        Navigator.pushNamedAndRemoveUntil(context, '/home', (route) => false);
        break;
      case 1:
        Navigator.pushNamedAndRemoveUntil(context, '/Jadwal', (route) => false);
        break;
      case 2:
        Navigator.pushNamedAndRemoveUntil(context, '/tugas', (route) => false);
        break;
      case 3:
        Navigator.pushNamedAndRemoveUntil(context, '/tentang', (route) => false);
        break;
    }
  }

  // Build UI utama
  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final namaHariSekarang = hariUrut[now.weekday - 1]; // Hari ini

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.white,
        elevation: 0,
        toolbarHeight: 80,
        title: Row(
          children: [
            Image.asset('assets/logo-studitrack.png', height: 120), // Logo
            const Spacer(),
            if (namaLengkap != null)
              GestureDetector(
                onTap: () => Navigator.pushNamed(context, '/profile'), // Ke profil
                child: Row(
                  children: [
                    Text(
                      namaLengkap!,
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: primaryColor),
                    ),
                    const SizedBox(width: 6),
                    const Icon(Icons.person, color: Color(0xFF052944)),
                  ],
                ),
              ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Input pencarian
            TextField(
              controller: searchController,
              decoration: InputDecoration(
                hintText: "Cari Jadwal...",
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: () {
                    searchController.clear();
                    setState(() => searchKeyword = "");
                    fetchJadwal(resetKeyword: true);
                  },
                ),
              ),
              onChanged: (value) {
                setState(() => searchKeyword = value.trim());
                fetchJadwal();
              },
            ),
            const SizedBox(height: 16),
            // Daftar jadwal
            Expanded(
              child: isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : FadeTransition(
                opacity: _fadeAnimation,
                child: jadwalList.isEmpty
                    ? const Center(child: Text("Belum ada data jadwal"))
                    : ListView.builder(
                  itemCount: jadwalList.length,
                  itemBuilder: (context, index) {
                    final item = jadwalList[index];
                    final isToday = item['hari'] == namaHariSekarang;
                    return _buildJadwalCard(item, isToday);
                  },
                ),
              ),
            ),
          ],
        ),
      ),
      // Tombol tambah
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pushNamed(context, '/jadwal-tambah').then((value) {
            if (value == true) {
              fetchJadwal(resetKeyword: true);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Jadwal berhasil ditambahkan')),
              );
            }
          });
        },
        backgroundColor: navBgColor,
        child: const Icon(Icons.add, color: Colors.white),
      ),
      // Navigasi bawah
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: navBgColor,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(24),
            topRight: Radius.circular(24),
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildNavItem(Icons.home, 'Beranda', 0, _selectedIndex == 0),
            _buildNavItem(Icons.schedule, 'Jadwal', 1, _selectedIndex == 1),
            _buildNavItem(Icons.task, 'Tugas', 2, _selectedIndex == 2),
            _buildNavItem(Icons.info_outline, 'Tentang', 3, _selectedIndex == 3),
          ],
        ),
      ),
    );
  }

  // Widget card untuk setiap item jadwal
  Widget _buildJadwalCard(dynamic item, bool isToday) {
    return Card(
      color: isToday ? primaryColor.withOpacity(0.15) : null,
      margin: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          item['foto_jadwal'] != null && item['foto_jadwal'] != ""
              ? ClipRRect(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(4),
              bottomLeft: Radius.circular(4),
            ),
            child: Image.network(
              item['foto_jadwal'],
              width: 100,
              height: 100,
              fit: BoxFit.cover,
            ),
          )
              : Container(
            width: 100,
            height: 100,
            color: Colors.grey.shade300,
            child: const Icon(Icons.person, color: Colors.grey),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item['matkul'],
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  Text("Pengajar: ${item['pengajar']}"),
                  Text("${item['hari']} | ${item['jam_mulai']} - ${item['jam_selesai']}"),
                  Text("Lokasi: ${item['lokasi']}"),
                ],
              ),
            ),
          ),
          // Tombol edit dan hapus
          Column(
            children: [
              IconButton(
                icon: const Icon(Icons.edit, color: Color(0xFF052944)),
                onPressed: () {
                  Navigator.pushNamed(
                    context,
                    '/jadwal-edit',
                    arguments: item,
                  ).then((value) {
                    if (value == true) {
                      fetchJadwal(resetKeyword: true);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Jadwal berhasil diperbarui')),
                      );
                    }
                  });
                },
              ),
              IconButton(
                icon: const Icon(Icons.delete, color: Colors.red),
                onPressed: () => hapusJadwal(item['id_jadwal']),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // Widget menu navigasi bawah
  Widget _buildNavItem(IconData icon, String label, int index, bool selected) =>
      GestureDetector(
        onTap: () => _onNavTapped(index),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              decoration: selected
                  ? const BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
              )
                  : null,
              padding: const EdgeInsets.all(8),
              child: Icon(icon,
                  color: selected ? primaryColor : Colors.white, size: 24),
            ),
            const SizedBox(height: 4),
            Text(label,
                style: TextStyle(
                    color: selected ? primaryColor : Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w500)),
          ],
        ),
      );
}
