import 'dart:convert'; // Untuk mengubah response JSON ke Map
import 'dart:io'; // Untuk membaca file foto dari storage

import 'package:flutter/material.dart'; // Framework UI Flutter
import 'package:image_picker/image_picker.dart'; // Untuk memilih foto dari galeri
import 'package:http/http.dart' as http; // Untuk HTTP request (POST ke API)
import 'package:shared_preferences/shared_preferences.dart'; // Untuk simpan/ambil data user lokal

class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key});

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController namaController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  File? _image; // Menyimpan gambar baru jika dipilih
  String? fotoUser; // Nama file/foto lama dari API
  String? idUsers; // ID user dari data login
  String? oldEmail; // Untuk cek apakah email berubah
  bool hapusFoto = false; // Status penghapusan foto
  bool isLoading = false; // Loading state untuk indikator loading

  @override
  void initState() {
    super.initState();
    loadUserData();// Ambil data user saat halaman dibuka
  }

  Future<void> loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    final userString = prefs.getString('user');
    if (userString != null) {
      final user = json.decode(userString);// Decode JSON ke Map
      setState(() {
        idUsers = user['id_users'].toString();
        namaController.text = user['nama_lengkap'];
        emailController.text = user['email'];
        oldEmail = user['email'];
        passwordController.text = user['password'];
        fotoUser = user['foto_user'];// Simpan foto lama
      });
    }
  }

  Future<void> pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() {
        _image = File(picked.path); // Simpan gambar baru
        hapusFoto = false; // Karena ganti, hapus foto jadi false
      });
    }
  }

  Future<void> updateProfile() async {
    if (!_formKey.currentState!.validate() || idUsers == null) return;

    setState(() => isLoading = true);

    final prefs = await SharedPreferences.getInstance();
    final uri = Uri.parse("http://fatimaa.fortunis11.com/studitrack-api/users-update.php");

    final request = http.MultipartRequest('POST', uri)
      ..fields['id_users'] = idUsers!
      ..fields['email'] = emailController.text.trim()
      ..fields['nama_lengkap'] = namaController.text.trim()
      ..fields['password'] = passwordController.text
      ..fields['hapus_foto'] = hapusFoto ? '1' : '0';// Kirim 1 jika user ingin hapus foto

    if (_image != null) {
      request.files.add(await http.MultipartFile.fromPath('foto_user', _image!.path));
    }

    final response = await request.send();
    final res = await response.stream.bytesToString();
    final data = json.decode(res);

    setState(() => isLoading = false);

    if (data['status'] == true) {
      final newEmail = emailController.text.trim();
      if (newEmail != oldEmail) {
        await prefs.remove('user');
        if (mounted) {
          Navigator.of(context).pushNamedAndRemoveUntil('/login', (_) => false);
        }
      } else {
        final updatedUser = {
          'id_users': idUsers,
          'nama_lengkap': namaController.text.trim(),
          'email': emailController.text.trim(),
          'password': passwordController.text,
          'foto_user': data['data']?['foto_user'] ?? '',
        };
        await prefs.setString('user', json.encode(updatedUser));
        if (mounted) {
          Navigator.pop(context); // Kembali ke halaman sebelumnya
        }
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(data['message'] ?? "Gagal memperbarui profil")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    const Color iconColor = Color(0xFF052944);
    const Color titleColor = Color(0xFF608CAD);
    final fullFotoUrl = (fotoUser != null && fotoUser!.isNotEmpty && !hapusFoto)
        ? (fotoUser!.startsWith('http')
        ? fotoUser
        : 'http://fatimaa.fortunis11.com/studitrack-api/$fotoUser')
        : null;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        toolbarHeight: 80,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: iconColor),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Image.asset('assets/logo-studitrack.png', height: 120),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              const Text(
                "Edit Profil",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: titleColor,
                ),
              ),
              const SizedBox(height: 20),

              Stack(
                alignment: Alignment.bottomRight,
                children: [
                  CircleAvatar(
                    radius: 60,
                    backgroundColor: Colors.grey[300],
                    backgroundImage: _image != null
                        ? FileImage(_image!)
                        : (fullFotoUrl != null
                        ? NetworkImage(fullFotoUrl)  // Foto dari API
                        : null) as ImageProvider?,
                    child: (_image == null && fullFotoUrl == null)
                        ? const Icon(Icons.person, size: 60, color: Colors.white)
                        : null,
                  ),
                  Positioned(
                    bottom: 0,
                    right: 4,
                    child: GestureDetector(
                      onTap: pickImage,
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: const BoxDecoration(
                          color: iconColor,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.edit, color: Colors.white, size: 20),
                      ),
                    ),
                  ),
                ],
              ),

              if (fotoUser != null && fotoUser!.isNotEmpty && _image == null && !hapusFoto)
                TextButton.icon(
                  onPressed: () {
                    setState(() {
                      hapusFoto = true;
                      _image = null;
                    });
                  },
                  icon: const Icon(Icons.delete_forever, color: Colors.red),
                  label: const Text("Hapus Foto", style: TextStyle(color: Colors.red)),
                ),

              const SizedBox(height: 30),

              // Input Nama
              TextFormField(
                controller: namaController,
                decoration: const InputDecoration(
                  labelText: 'Nama Lengkap',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                value == null || value.isEmpty ? 'Nama wajib diisi' : null,
              ),
              const SizedBox(height: 16),

              // Input Email
              TextFormField(
                controller: emailController,
                decoration: const InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                value == null || value.isEmpty || !value.contains('@')
                    ? 'Email tidak valid'
                    : null,
              ),
              const SizedBox(height: 16),

              // Input Password
              TextFormField(
                controller: passwordController,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Password',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                value == null || value.length < 4
                    ? 'Password minimal 4 karakter'
                    : null,
              ),
              const SizedBox(height: 24),

              isLoading
                  ? const CircularProgressIndicator()
                  : SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: updateProfile,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: iconColor,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text("Simpan Perubahan", style: TextStyle(color: Colors.white)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
