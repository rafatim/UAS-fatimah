import 'dart:convert'; // Digunakan untuk mengubah data JSON dari dan ke format Map/String
import 'package:flutter/material.dart'; // Paket UI utama dari Flutter
import 'package:http/http.dart' as http; // Paket HTTP untuk komunikasi ke API
import 'package:shared_preferences/shared_preferences.dart'; // Untuk menyimpan data secara lokal (seperti data login)

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();// Menghubungkan ke state
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>(); // Kunci unik untuk validasi form
  final TextEditingController _emailController = TextEditingController(); // Kontrol input email
  final TextEditingController _passwordController = TextEditingController(); // Kontrol input password

  bool _loading = false; // Menandakan apakah login sedang berlangsung
  String? _loginError; // Menyimpan pesan error jika login gagal

  Future<void> login() async {
    if (!_formKey.currentState!.validate()) return; // Validasi form, jika tidak valid hentikan proses

    setState(() {
      _loading = true; // Menunjukkan loading
      _loginError = null; // Reset error sebelumnya
    });

    // Kirim permintaan POST ke API login
    final response = await http.post(
      Uri.parse('http://fatimaa.fortunis11.com/studitrack-api/users-login.php'),
      body: {
        'email': _emailController.text.trim(), // Kirim email
        'password': _passwordController.text,   // Kirim password
      },
    );

    final data = json.decode(response.body); // Decode response JSON

    setState(() => _loading = false); // Selesai loading

    if (data['status']) {
      // Jika login berhasil
      SharedPreferences prefs = await SharedPreferences.getInstance(); // Ambil instance local storage
      prefs.setString('user', json.encode(data['data'])); // Simpan data user ke local storage
      Navigator.pushReplacementNamed(context, '/home'); // Arahkan ke halaman beranda
    } else {
      setState(() => _loginError = data['message']); // Tampilkan error login jika gagal
    }
  }

  @override
  Widget build(BuildContext context) {
    const primaryColor = Color(0xFF1C3A55); // Warna utama tombol login

    return Scaffold(
      body: SingleChildScrollView( // Agar tampilan bisa digulir jika keyboard muncul
        padding: const EdgeInsets.all(24), // Padding sisi dalam layar
        child: Form(
          key: _formKey, // Menyambungkan form dengan key untuk validasi
          child: Column(
            children: [
              const SizedBox(height: 80), // Jarak atas
              Image.asset('assets/logo-studitrack.png', height: 180), // Logo StudiTrack
              const SizedBox(height: 10),

              // Email
              TextFormField(
                controller: _emailController, // Menghubungkan ke controller email
                keyboardType: TextInputType.emailAddress, // Menampilkan keyboard email
                decoration: const InputDecoration(
                  labelText: 'Email', // Label input
                  prefixIcon: Icon(Icons.email), // Ikon di kiri input
                ),
                validator: (value) { // Validasi input
                  if (value == null || value.isEmpty) {
                    return 'Email wajib diisi'; // Tidak boleh kosong
                  }
                  final emailReg = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
                  if (!emailReg.hasMatch(value)) {
                    return 'Format email tidak valid'; // Format harus email
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Password
              TextFormField(
                controller: _passwordController, // Controller untuk password
                obscureText: true, // Menyembunyikan karakter saat diketik
                decoration: const InputDecoration(
                  labelText: 'Password',
                  prefixIcon: Icon(Icons.lock),
                ),
                validator: (value) =>
                value == null || value.isEmpty ? 'Password wajib diisi' : null, // Validasi
              ),
              const SizedBox(height: 8),

              // Pesan error dari backend
              if (_loginError != null)
                Container(
                  alignment: Alignment.centerLeft,
                  padding: const EdgeInsets.only(top: 4, left: 8),
                  child: Text(
                    _loginError!, // Tampilkan pesan error
                    style: const TextStyle(color: Colors.red), // Warna merah
                  ),
                ),
              const SizedBox(height: 24),

              // Tombol Login
              SizedBox(
                width: double.infinity, // Tombol memenuhi lebar layar
                child: ElevatedButton(
                  onPressed: _loading ? null : login, // Tidak bisa diklik saat loading
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryColor, // Warna background tombol
                    foregroundColor: Colors.white, // Warna teks
                    padding: const EdgeInsets.symmetric(vertical: 14), // Padding atas-bawah
                  ),
                  child: _loading
                      ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(strokeWidth: 2), // Loading spinner
                  )
                      : const Text('LOGIN'), // Teks jika tidak loading
                ),
              ),

              const SizedBox(height: 24),
              TextButton(
                onPressed: () {
                  Navigator.pushReplacementNamed(context, '/register'); // Arahkan ke register
                },
                child: const Text("Belum punya akun? Daftar"), // Teks link
              )
            ],
          ),
        ),
      ),
    );
  }
}