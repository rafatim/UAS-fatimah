// Import library yang diperlukan
import 'dart:convert'; // Untuk konversi data JSON
import 'dart:io'; // Untuk mengelola file (misal gambar)
import 'package:flutter/material.dart'; // Framework UI Flutter
import 'package:image_picker/image_picker.dart'; // Untuk memilih gambar dari galeri
import 'package:http/http.dart' as http; // Untuk komunikasi HTTP
import 'package:shared_preferences/shared_preferences.dart'; // Untuk menyimpan dan mengambil data lokal (user login)

class TugasTambahPage extends StatefulWidget {
  const TugasTambahPage({super.key});

  @override
  State<TugasTambahPage> createState() => _TugasTambahPageState();
}

class _TugasTambahPageState extends State<TugasTambahPage> {
  final _formKey = GlobalKey<FormState>(); // Key untuk validasi form
  final TextEditingController judulController = TextEditingController(); // Controller untuk input judul
  final TextEditingController deskripsiController = TextEditingController(); // Controller untuk input deskripsi
  final TextEditingController tanggalController = TextEditingController(); // Controller untuk input tanggal deadline

  String? idUsers; // Menyimpan id pengguna
  String? idJadwal; // Menyimpan id jadwal terpilih
  File? _image; // File gambar tugas yang dipilih
  bool isLoading = false; // Indikator loading saat submit
  List<dynamic> daftarJadwal = []; // Menyimpan daftar jadwal user

  @override
  void initState() {
    super.initState();
    loadUserData(); // Load data user saat pertama kali halaman dibuka
  }

  // Fungsi untuk mengambil data user dari SharedPreferences
  Future<void> loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    final userString = prefs.getString('user'); // Ambil string user
    if (userString != null) {
      final user = json.decode(userString); // Ubah ke Map
      idUsers = user['id_users'];
      fetchJadwal(); // Ambil jadwal berdasarkan idUsers
    }
  }

  // Fungsi untuk mengambil daftar jadwal dari API
  Future<void> fetchJadwal() async {
    final response = await http.get(Uri.parse(
        "http://fatimaa.fortunis11.com/studitrack-api/jadwal-list.php?id_users=$idUsers"));
    final data = json.decode(response.body);
    if (data['status']) {
      setState(() {
        daftarJadwal = data['data']; // Set daftar jadwal ke state
      });
    }
  }

  // Fungsi untuk memilih gambar dari galeri
  Future<void> pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() => _image = File(picked.path)); // Simpan file gambar
    }
  }

  // Fungsi untuk mengirim data tugas ke server
  Future<void> submitTugas() async {
    if (!_formKey.currentState!.validate()) return; // Validasi form
    if (idUsers == null || idJadwal == null) return; // Pastikan user & jadwal terisi

    setState(() => isLoading = true); // Tampilkan indikator loading

    final uri = Uri.parse("http://fatimaa.fortunis11.com/studitrack-api/tugas-create.php");
    final request = http.MultipartRequest('POST', uri)
      ..fields['id_users'] = idUsers!
      ..fields['id_jadwal'] = idJadwal!
      ..fields['judul'] = judulController.text.trim()
      ..fields['deskripsi'] = deskripsiController.text.trim()
      ..fields['tanggal_daedline'] = tanggalController.text;

    if (_image != null) {
      request.files.add(await http.MultipartFile.fromPath('foto_tugas', _image!.path)); // Tambah file gambar jika ada
    }

    final response = await request.send(); // Kirim request ke server
    final responseData = await response.stream.bytesToString(); // Ambil respon
    final result = json.decode(responseData); // Decode JSON

    setState(() => isLoading = false); // Sembunyikan loading

    if (result['status']) {
      if (mounted) {
        Navigator.pop(context, true); // Kembali ke halaman sebelumnya dengan status true (berhasil)
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Tugas berhasil ditambahkan")),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result['message'] ?? "Gagal menambah tugas")),
      );
    }
  }

  // Fungsi untuk menampilkan dialog konfirmasi saat tombol back ditekan
  Future<bool> _onBackPressed() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Konfirmasi"),
        content: const Text("Yakin batal menambah tugas?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text("Tidak")),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text("Ya")),
        ],
      ),
    );
    return confirm == true; // Mengembalikan true jika user memilih "Ya"
  }

  @override
  Widget build(BuildContext context) {
    const Color primaryColor = Color(0xFF052944); // Warna utama aplikasi

    return WillPopScope(
      onWillPop: _onBackPressed, // Intersep tombol back
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          toolbarHeight: 80, // Tinggi app bar
          elevation: 0, // Hilangkan bayangan
          backgroundColor: Colors.white,
          automaticallyImplyLeading: false, // Hilangkan tombol back bawaan
          title: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back, color: primaryColor),
                onPressed: () async {
                  final canPop = await _onBackPressed(); // Tampilkan dialog konfirmasi
                  if (canPop) Navigator.pop(context, false); // Kembali jika disetujui
                },
              ),
              Image.asset('assets/logo-studitrack.png', height: 120), // Logo di tengah kiri
              const Spacer(), // Dorong ke kanan
            ],
          ),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey, // Gunakan key validasi
            child: Column(
              children: [
                const Center(
                  child: Text(
                    'Tambah Tugas', // Judul form
                    style: TextStyle(
                      color: Color(0xFF608CAD),
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                // Dropdown untuk memilih mata kuliah dari jadwal
                DropdownButtonFormField<String>(
                  value: idJadwal,
                  items: daftarJadwal.map<DropdownMenuItem<String>>((item) {
                    return DropdownMenuItem<String>(
                      value: item['id_jadwal'],
                      child: Text(item['matkul']),
                    );
                  }).toList(),
                  onChanged: (val) => setState(() => idJadwal = val),
                  decoration: const InputDecoration(
                    labelText: 'Mata Kuliah',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) => value == null ? 'Mata kuliah wajib dipilih' : null,
                ),
                const SizedBox(height: 16),
                // Input judul tugas
                TextFormField(
                  controller: judulController,
                  decoration: const InputDecoration(
                    labelText: 'Judul Tugas',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) => value == null || value.isEmpty ? 'Judul wajib diisi' : null,
                ),
                const SizedBox(height: 16),
                // Input deskripsi tugas
                TextFormField(
                  controller: deskripsiController,
                  decoration: const InputDecoration(
                    labelText: 'Deskripsi',
                    border: OutlineInputBorder(),
                  ),
                  maxLines: 3,
                  validator: (value) => value == null || value.isEmpty ? 'Deskripsi wajib diisi' : null,
                ),
                const SizedBox(height: 16),
                // Input tanggal deadline (date picker)
                TextFormField(
                  controller: tanggalController,
                  decoration: const InputDecoration(
                    labelText: 'Tanggal Deadline',
                    border: OutlineInputBorder(),
                  ),
                  readOnly: true, // Tidak bisa diketik manual
                  onTap: () async {
                    final now = DateTime.now();
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: now,
                      firstDate: now,
                      lastDate: DateTime(now.year + 2),
                    );
                    if (picked != null) {
                      tanggalController.text = picked.toIso8601String().split('T').first; // Format yyyy-MM-dd
                    }
                  },
                  validator: (value) => value == null || value.isEmpty ? 'Tanggal wajib diisi' : null,
                ),
                const SizedBox(height: 16),
                // Input foto tugas
                GestureDetector(
                  onTap: pickImage,
                  child: InputDecorator(
                    decoration: const InputDecoration(
                      labelText: 'Foto Tugas (Opsional)',
                      border: OutlineInputBorder(),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.image, color: Colors.grey),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            _image != null ? _image!.path.split('/').last : 'Pilih gambar', // Tampilkan nama file
                            style: TextStyle(
                              color: _image != null ? Colors.black87 : Colors.grey,
                            ),
                          ),
                        ),
                        const Icon(Icons.upload_file, color: Colors.grey),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                // Tombol simpan
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: isLoading ? null : submitTugas, // Disable saat loading
                    style: ElevatedButton.styleFrom(
                      backgroundColor: primaryColor,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: isLoading
                        ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                        : const Text("Simpan", style: TextStyle(color: Colors.white)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
