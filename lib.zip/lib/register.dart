import 'dart:convert'; // Untuk mengubah data JSON dari dan ke Map<String, dynamic>
import 'dart:io'; // Untuk memproses file (digunakan untuk upload foto)
import 'package:flutter/material.dart'; // Paket UI Flutter
import 'package:http/http.dart' as http; // Untuk melakukan request ke API
import 'package:image_picker/image_picker.dart'; // Untuk memilih gambar dari galeri

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();// Menghubungkan ke State
}

class _RegisterPageState extends State<RegisterPage> {
  final _formKey = GlobalKey<FormState>(); // Kunci unik untuk validasi form

  // Controller untuk input form
  final TextEditingController emailController = TextEditingController();
  final TextEditingController namaController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  File? _image; // Untuk menyimpan file gambar yang dipilih
  bool isLoading = false; // Menandakan proses loading saat registrasi

  final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+'); // Regex untuk validasi format email

  String? emailErrorMessage; // Pesan error jika email sudah terdaftar

  Future<void> pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);// Pilih gambar dari galeri
    if (picked != null) {
      setState(() {
        _image = File(picked.path);// Simpan gambar ke dalam _image
      });
    }
  }

  Future<void> register() async {
    emailErrorMessage = null; // Reset error email sebelumnya

    if (!_formKey.currentState!.validate()) return; // Jika form tidak valid, batalkan

    setState(() => isLoading = true); // Tampilkan loading

    final uri = Uri.parse("http://fatimaa.fortunis11.com/studitrack-api/users-create.php"); // Endpoint API
    final request = http.MultipartRequest('POST', uri)
      ..fields['email'] = emailController.text.trim() // Kirim email ke API
      ..fields['nama_lengkap'] = namaController.text.trim() // Kirim nama
      ..fields['password'] = passwordController.text; // Kirim password

    if (_image != null) {
      // Jika ada gambar, kirim juga file foto
      request.files.add(await http.MultipartFile.fromPath('foto_user', _image!.path));
    }

    final response = await request.send(); // Kirim request ke server
    final res = await response.stream.bytesToString(); // Ambil response sebagai string
    final data = json.decode(res); // Decode JSON dari response

    setState(() => isLoading = false); // Selesai loading

    if (data['status'] == true) {
      // Jika berhasil daftar, arahkan ke halaman login
      Navigator.pushReplacementNamed(context, '/login');
    } else {
      // Tangani error dari API
      final msg = data['message']?.toLowerCase() ?? '';
      if (msg.contains('email') && msg.contains('terdaftar')) {
        setState(() => emailErrorMessage = 'Email sudah terdaftar');
      } else {
        setState(() => emailErrorMessage = data['message'] ?? 'Registrasi gagal');
      }
      _formKey.currentState!.validate(); // Ulangi validasi agar error tampil
    }
  }

  @override
  Widget build(BuildContext context) {
    const primaryColor = Color(0xFF1C3A55); // Sesuai warna logo StudiTrack

    return Scaffold(
      body: SingleChildScrollView( // Supaya scroll bisa dilakukan jika layar kecil atau keyboard terbuka
        padding: const EdgeInsets.all(24), // Jarak dari sisi layar
        child: Form(
          key: _formKey, // Menghubungkan dengan validator
          child: Column(
            children: [
              const SizedBox(height: 60), // Jarak atas
              Image.asset('assets/logo-studitrack.png', width: 180), // Logo StudiTrack
              const SizedBox(height: 10),

              // Email
              TextFormField(
                controller: emailController, // Controller input email
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  labelText: 'Email',
                  prefixIcon: Icon(Icons.email),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Email wajib diisi'; // Validasi kosong
                  } else if (!emailRegex.hasMatch(value)) {
                    return 'Format email tidak valid'; // Validasi format
                  } else if (emailErrorMessage != null) {
                    return emailErrorMessage; // Validasi dari backend
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Nama
              TextFormField(
                controller: namaController,
                decoration: const InputDecoration(
                  labelText: 'Nama Lengkap',
                  prefixIcon: Icon(Icons.person),
                ),
                validator: (value) =>
                value!.isEmpty ? 'Nama wajib diisi' : null,
              ),
              const SizedBox(height: 16),

              // Password
              TextFormField(
                controller: passwordController,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Password',
                  prefixIcon: Icon(Icons.lock),
                ),
                validator: (value) =>
                value == null || value.length < 4
                    ? 'Password minimal 4 karakter'
                    : null,
              ),
              const SizedBox(height: 16),

              // Foto (optional)
              TextFormField(
                readOnly: true, // Tidak bisa diketik manual
                onTap: pickImage, // Pilih gambar saat diklik
                decoration: InputDecoration(
                  labelText: 'Foto (Opsional)',
                  prefixIcon: const Icon(Icons.image),
                  hintText: _image == null
                      ? 'Pilih gambar jika ingin'
                      : _image!.path.split('/').last, // Tampilkan nama file
                  suffixIcon: const Icon(Icons.upload_file),
                ),
              ),

              const SizedBox(height: 30),
              isLoading
                  ? const CircularProgressIndicator() // Spinner loading saat proses daftar
                  : SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: register, // Jalankan fungsi register saat ditekan
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryColor,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text("DAFTAR"),
                ),
              ),

              const SizedBox(height: 24),
              TextButton(
                onPressed: () => Navigator.pushReplacementNamed(context, '/login'),// Pindah ke login
                child: const Text("Sudah punya akun? Login"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
